var config = {
  version: "1.1.17",
  octinnId: "1351",
  name: "塔罗牌无限次情感问答",
  logo: "https://static.shengri.cn/uploads/QA_mp/freetarot/%E7%94%BB%E6%9D%BF.png",
  appId: "wxe005e57d5edaa93f",
  appKey: "44b1657f7ed812fb4a6c71c303ae9f1e",
  user_agreement: "https://www.aataluo.com/agreement_wwtl.html",
  privacy_policy: "https://www.aataluo.com/agreement_wwtlysxy.html",
  user_agreement_name: '问问用户协议',
  privacy_policy_name: '问问隐私政策'
};module.exports = config;