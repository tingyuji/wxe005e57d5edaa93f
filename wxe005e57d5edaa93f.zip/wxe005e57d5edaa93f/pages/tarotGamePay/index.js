var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var api = require("./../../utils/api.js");var app = getApp();var canSubmit = true;var topArray = [20, 59, 98, 137];var time = [6.5, 7, 7.5, 8, 8.5];var cycle = null;var bulletChatList = [];var id = 0;Page({
  data: {
    windowWidth: 0,
    windowHeight: 0,
    showPrompt: false,
    couponNum: 0,
    couponId: "",
    options: {},
    disabled: false,
    inputAnimation: {},
    pageBottom: 0,
    questionText: "",
    postId: 0,
    system: "",
    isToast: false,
    scrollX: true,
    // 选中塔罗牌的数据
    showChooseTarot: [],
    redirectConfig: {},
    isIos: false,
    templateIds: [],
    showTextarea: true,
    bullet: ["我表白会成功吗", "他为什么不主动找我聊天了", "我喜欢的人喜欢我吗", "我答应和他复合会幸福吗", "他会来找我复合吗", "他是不是真的喜欢我", "我会和他在一起到结婚吗", "我和他应该离婚吗", "我原谅他后会和以前一样吗", "分手后他有想过我吗", "我什么时候能脱单", "分手了怎么才能让对方主动复合", "他是不是出轨了"]
  },
  onLoad: function onLoad(options) {
    var _this = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
      var questionText;
      return _regeneratorRuntime2().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            questionText = "";
            if (options.questionText) {
              questionText = options.questionText;
              wx.removeStorageSync("questionText");
            } else {
              if (wx.getStorageSync("questionText")) {
                questionText = wx.getStorageSync("questionText");
                wx.removeStorageSync("questionText");
              }
            }
            _this.setData({
              options: options,
              questionText: questionText
            });
            _this.setImages();
          case 4:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }))();
  },
  onShow: function onShow() {
    var _this2 = this;
    var that = this;
    canSubmit = true;
    var tarotResultData = wx.getStorageSync("tarotResultData");
    wx.getSystemInfo({
      success: function success(res) {
        console.log(res);
        _this2.setData({
          system: res.system,
          isIos: res.system.indexOf("iOS") > -1,
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        });
      }
    });
    that.setData({
      showChooseTarot: tarotResultData
    });
    if (that.data.options.questionText) {
      wx.showToast({
        title: "可以自定义编辑问题",
        icon: "none",
        duration: 1500
      });
    }
  },
  onReady: function onReady() {
    var that = this;
    this.tarotPay = this.selectComponent("#tarotPay");
    this.consultDialog = this.selectComponent("#consultDialog");
  },
  noClose: function noClose() {
    return;
  },
  setImages: function setImages() {
    var imagesArr = [];
    var tarotResultData = wx.getStorageSync("tarotResultData");
    tarotResultData.forEach(function (v, k) {
      imagesArr.push({
        id: v.id,
        position: v.position,
        url: v.image,
        width: v.width,
        height: v.height,
        orientation: v.orientation
      });
    });
    return imagesArr;
  },
  // 咨询塔罗师
  showPromptFn: function showPromptFn(e) {
    var that = this;
    var souce = e.currentTarget.dataset.souce;
    if (this.data.questionText.length < 5) {
      return wx.showToast({
        title: "提问不得少于5个字",
        icon: "none",
        duration: 800
      });
    }
    // 初始化数据
    this.tarotPay.initData();
    this.consultDialog.initData();
    if (souce == "cancel") {
      wx.setStorageSync("questionText", this.data.questionText);
    }
    this.tarotPay.setPayParams({
      circle_id: 12,
      type: 2,
      content: this.data.questionText,
      images: this.setImages(),
      is_anonymous: 0
    });
    this.setData({
      showTextarea: false
    });
    this.consultDialog.setQuestionText(this.data.questionText);
    this.consultDialog.showDialog();
  },
  hideDialog: function hideDialog() {
    console.log(".>>>>>>>>>>>>>>>>");
    this.setData({
      showTextarea: true
    });
  },
  showPayCom: function showPayCom() {
    return this.tarotPay.showPay();
  },
  // 使用提问券支付
  useCouponPay: function useCouponPay(e) {
    return this.tarotPay.useCouponPay(e.detail, this.data.options.inviteUserId);
  },
  focus: function focus(e) {
    var animation = wx.createAnimation({
      transformOrigin: "0 100%",
      duration: 300,
      timingFunction: "linear",
      delay: 0
    });
    animation.bottom(e.detail.height).step();
    this.setData({
      pageBottom: e.detail.height * 2
      // inputAnimation: animation.export()
    });
  },
  blur: function blur() {
    this.setData({
      pageBottom: 0
    });
  },
  inputQuestion: function inputQuestion(e) {
    this.setData({
      questionText: e.detail.value
    });
  },
  componentContext: function componentContext(e) {
    if (e.detail) {
      this.setData({
        questionText: e.detail
      });
    }
  }
});