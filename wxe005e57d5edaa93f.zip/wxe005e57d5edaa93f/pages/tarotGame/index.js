var _typeof2 = require("../../@babel/runtime/helpers/typeof");var api = require("./../../utils/api.js");var app = getApp();var isClick = true;Page({
  data: {
    windowWidth: 0,
    windowHeight: 0,
    options: {},
    pageShow: true,
    clickIndex: -1,
    // 控制展示入场动画区域
    showEntranceAnimBox: false,
    // 控制展示洗牌动画区域
    showStartInterface: false,
    // 控制展示洗牌动画(此时文字按钮不展示)
    showShuffleDeckAnim: false,
    // 控制展示发牌动画区域
    showOperatingArea: false,
    // 控制展示抽牌前的提示文案
    showReadyFont: true,
    // U型塔罗牌的数据
    tarotData: [],
    // 选中塔罗牌的数据
    chooseTarot: [],
    // 选中塔罗牌下方虚线框的数据
    showChooseTarot: [{
      text: "过去",
      name: ""
    }, {
      text: "现在",
      name: ""
    }, {
      text: "未来",
      name: ""
    }],
    // 接口获取抽选的塔罗数据
    tarotResultData: [],
    showAnmition: false,
    firstStepStatus: 0,
    animationView: [],
    animationData: null,
    aid: ""
  },
  onLoad: function onLoad(options) {
    var _this = this;
    var that = this;
    // let tarotNewData = new Array(77).fill(undefined);
    var tarotNewData = new Array(77).fill(undefined).map(function (v, k) {
      return _this.deepClone1({
        trans: ""
      });
    });
    if (options && "aid" in options) {
      this.setData({
        aid: options.aid
      });
    }
    this.setData({
      options: options,
      tarotData: tarotNewData
    });
    this.fetchData();
    setTimeout(function () {
      that.setData({
        showEntranceAnimBox: true,
        showStartInterface: true
      });
    }, 200);
    // this.setStep2ImageAni()
  },
  onShow: function onShow() {
    var _this2 = this;
    var that = this;
    isClick = true;
    wx.getSystemInfo({
      success: function success(res) {
        _this2.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        });
      }
    });
    if (app.isLogin()) {
      that.fetchCouponNum();
    }
  },
  deepClone1: function (_deepClone) {
    function deepClone1(_x) {
      return _deepClone.apply(this, arguments);
    }
    deepClone1.toString = function () {
      return _deepClone.toString();
    };
    return deepClone1;
  }(function (obj) {
    //判断拷贝的要进行深拷贝的是数组还是对象，是数组的话进行数组拷贝，对象的话进行对象拷贝
    var objClone = Array.isArray(obj) ? [] : {};
    //进行深拷贝的不能为空，并且是对象或者是
    if (obj && _typeof2(obj) === "object") {
      var key;
      for (key in obj) {
        if (obj.hasOwnProperty(key)) {
          if (obj[key] && _typeof2(obj[key]) === "object") {
            objClone[key] = deepClone1(obj[key]);
          } else {
            objClone[key] = obj[key];
          }
        }
      }
    }
    return objClone;
  }),
  shuffleDeckFn: function shuffleDeckFn(e) {
    console.log("shuffleDeckFn");
    var that = this;
    that.setData({
      showShuffleDeckAnim: true,
      showEntranceAnimBox: false,
      firstStepStatus: 1
    });
    setTimeout(function () {
      var animationView = that.setStep2ImageAni();
      that.setData({
        firstStepStatus: 2
      });
      setTimeout(function () {
        that.setData({
          animationView: animationView.map(function (item) {
            return item.export();
          })
        });
      }, 10);
    }, 900);
    setTimeout(function () {
      that.setData({
        showOperatingArea: true
      });
    }, 5000);
  },
  getRandomNumber: function getRandomNumber(lower, upper, n) {
    var arr = [];
    for (var i = 0; i < n; i++) {
      var number = Math.random() * (upper - lower + 1) + lower;
      if (arr.indexOf(number) < 0) {
        arr.push(number);
      } else {
        i--;
      }
    }
    return arr;
  },
  setStep2ImageAni: function setStep2ImageAni() {
    var that = this;
    var cnt = this.data.tarotData.length;
    var animationView = this.data.tarotData.map(function (item, index) {
      return that.setItemAni();
    });
    return animationView;
  },
  setItemAni: function setItemAni() {
    var that = this;
    var arr = that.getRandomNumber(-120, 230, 4);
    var rotate = that.getRandomNumber(-180, 180, 2);
    var animation = wx.createAnimation({
      duration: 3200,
      transformOrigin: "-50% -10% 0",
      timingFunction: "ease"
    });
    animation.translateX(arr[0]).translateY(arr[1]).rotate(rotate[0]).scale(0.5, 0.5).step({
      duration: 800
    }).translateX(0).translateY(0).rotate(0).scale(0.5, 0.5).step({
      duration: 800
    }).translateX(arr[2]).translateY(arr[3]).rotate(rotate[1]).scale(0.5, 0.5).step({
      duration: 800
    }).translateX(0).translateY(0).rotate(0).scale(0.5, 0.5).step({
      duration: 800
    });
    return animation;
  },
  checkLoginStatus: function checkLoginStatus() {
    // 如果没有登录，就去登录授权
    if (!app.isLogin()) {
      if (app.getAllow()) {
        wx.navigateTo({
          url: "../login/login"
        });
      } else {
        wx.navigateTo({
          url: "../authorization/authorization"
        });
      }
      return;
    }
    return true;
  },
  fetchData: function fetchData() {
    var that = this;
    var url = api.baseUrl + "brapi/tarot/result";
    api.fetchGet(url).then(function (res) {
      that.setData({
        tarotResultData: res.result
      });
    });
  },
  fetchCouponNum: function fetchCouponNum() {
    var that = this;
    api.fetchGet(api.baseUrl + "ask/invite/lists", {}).then(function (res) {});
  },
  submitFormid2: function submitFormid2(e) {
    var that = this;
    var chooseTarot = that.data.chooseTarot;
    // 消息推送埋点
    var formId = e.detail.formId;
    if (app.globalData.wxInfo) {
      var openId = app.globalData.wxInfo.openId;
      console.log("---------------");
      console.log(formId);
      api.fetchPost(api.baseUrl + "wechat/saveformdata", {
        open_id: openId,
        form_id: formId,
        context: {
          type: 1
        },
        noTip: true
      }).then(function (res) {});
    }
  },
  choose: function choose(e) {
    var that = this;
    var tarotData = that.data.tarotData;
    var index = e.currentTarget.dataset.index;
    console.log("index---->", index);
    var chooseTarot = that.data.chooseTarot;
    var tarotResultData = that.data.tarotResultData;
    var showChooseTarot = JSON.parse(JSON.stringify(that.data.showChooseTarot));
    if (that.checkLoginStatus()) {
      // 检测有没有wxAppSession，没有需要重新授权
      // let wxAppSession = api.header['OI-WXAPP-SESSION'];
      // if(!wxAppSession){
      //     wx.navigateTo({url: '../authorization/authorization'})
      // }
      if (!isClick || chooseTarot.length == 3) {
        console.log("不能点击了");
        return;
      }
      isClick = false;
      // 给选中的塔罗加动画
      console.log("tarot--->", tarotData[index]);
      tarotData[index] = {
        trans: "removeAnim"
      };
      console.log("tarot--->", tarotData[index]);
      // 向选中的塔罗的数组中添加一个包含动画的对象
      chooseTarot.push({
        anim: "chooseTarotItemAnim" + chooseTarot.length,
        res: tarotResultData[chooseTarot.length]
      });
      that.setData({
        clickIndex: index,
        showReadyFont: false,
        tarotData: tarotData,
        chooseTarot: chooseTarot
      });
      // 向下方放置选中塔罗的地方添加相应的塔罗名称
      setTimeout(function () {
        var name = tarotResultData[chooseTarot.length - 1].name;
        var position = tarotResultData[chooseTarot.length - 1].position == 1 ? "正位" : "逆位";
        showChooseTarot[chooseTarot.length - 1].name = "".concat(name, " \xB7 ").concat(position);
        that.setData({
          showChooseTarot: showChooseTarot
        });
        if (chooseTarot.length == 3) {
          wx.setStorageSync("tarotResultData", tarotResultData);
          that.setData({
            pageShow: false
          });
          setTimeout(function () {
            if (that.data.options.inviteUserId) {
              wx.redirectTo({
                url: "../tarotGamePay/index?inviteUserId=" + that.data.options.inviteUserId
              });
            } else if (that.data.options.questionText) {
              wx.redirectTo({
                url: "../tarotGamePay/index?questionText=" + that.data.options.questionText
              });
            } else {
              wx.redirectTo({
                url: "../tarotGamePay/index"
              });
            }
          }, 250);
        }
      }, 4000);
      setTimeout(function () {
        isClick = true;
      }, 4100);
    }
  }
});