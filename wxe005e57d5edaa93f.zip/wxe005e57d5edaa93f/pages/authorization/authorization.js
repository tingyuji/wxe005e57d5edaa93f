var api = require("../../utils/api.js");var config = require("../../config.js");var app = getApp();var timer;Page({
  data: {
    name: config.name,
    logo: config.logo,
    userAgreementName: config.user_agreement_name,
    privacyPolicyName: config.privacy_policy_name,
    wxInfo: {
      avatarUrl: "",
      nickName: ""
    },
    isAuthorization: false,
    hasAgree: false
  },
  onShow: function onShow() {
    this.checkAuthStatus();
  },
  onLoad: function onLoad(options) {
    this.setData(options);
    wx.login({
      success: function success(res) {
        console.log("res", res);
        wx.setStorageSync("loginCode", res.code);
      }
    });
  },
  onHide: function onHide() {
    clearTimeout(timer);
  },
  onUnload: function onUnload() {
    clearTimeout(timer);
    wx.removeStorageSync("loginCode");
  },
  checkAuthStatus: function checkAuthStatus() {
    var wxInfo = wx.getStorageSync("wxInfo") || {};
    if ("avatarUrl" in wxInfo && wxInfo.avatarUrl != "") {
      this.setData({
        wxInfo: {
          avatarUrl: wxInfo.avatarUrl,
          nickName: wxInfo.nickName
        },
        isAuthorization: true
      });
    } else {
      this.setData({
        isAuthorization: false
      });
    }
  },
  bindGetUserInfo: function bindGetUserInfo() {
    var that = this;
    // wx.getUserProfile({
    //   desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
    //   success: (res) => {
    //     console.log('1111111',res)
    //     // this.setData({
    //     //   userInfo: res.userInfo,
    //     //   hasUserInfo: true
    //     // })
    //   }
    // })

    // app.getUserInfo(function (resp) {})

    // wx.getSetting({
    //   success: function (res) {
    //     console.log("sucessres", res);
    // if (res.authSetting["scope.userInfo"]) {
    if (!this.data.hasAgree) {
      return wx.showToast({
        title: '请先勾选协议',
        icon: 'none',
        duration: 1500
      });
    }
    app.setAllow(1);
    app.getUserInfo(function (resp) {
      that.checkAuthStatus();
      timer = setTimeout(function () {
        clearTimeout(timer);
        that.pageRouter(resp);
      }, 1500);
    });
    // }
    //   },
    // });
  },
  pageRouter: function pageRouter(resp) {
    var that = this;
    var redirect = that.data.redirect;
    var url = "../login/login";
    // 如果登录了，直接返回，没有登录去手机号登录
    if (!app.isLogin()) {
      if (redirect) {
        url = "../login/login?redirect=" + redirect;
      }
      return wx.redirectTo({
        url: url
      });
    }
    //nonage  1 未成年，0 - 不是， -1 未知
    //有些用户是授权后，直接被获取了userInfo的信息，这里是为了兼容用户授权
    if (resp.nonage == -1) {
      //新用户去验证身份
      if (resp.birth_y == 0) {
        wx.setStorageSync("nonage", -1);
        wx.redirectTo({
          url: "../identity/index"
        });
      } else {
        //老用户赋值0
        wx.setStorageSync("nonage", 0);
        wx.navigateBack({
          delta: 1
        });
      }
    }
    if (resp.nonage == 0) {
      wx.setStorageSync("nonage", 0);
      wx.navigateBack({
        delta: 1
      });
    }
    if (resp.nonage == 1) {
      wx.setStorageSync("nonage", 1);
      wx.redirectTo({
        url: "../identity/index"
      });
    }
  },
  navBack: function navBack() {
    return wx.navigateBack();
  },
  handleClick: function handleClick() {
    this.setData({
      hasAgree: !this.data.hasAgree
    });
  },
  handleToLink: function handleToLink(e) {
    var idx = e.currentTarget.dataset.idx;
    wx.navigateTo({
      url: "../webView/index?idx=" + idx
    });
  }
});