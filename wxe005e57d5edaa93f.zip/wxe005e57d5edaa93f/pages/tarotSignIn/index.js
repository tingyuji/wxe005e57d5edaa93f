var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var api = require('../../utils/api.js');var app = getApp();var isClick = true;var timeout0, timeout1, timeout2, timeout3, timeout4, timeout5, timeout6, timeout7, timeout8;var timeOut;var Amultiple = 2;var isShare = true;var showNum = 0;Page({
  data: {
    qbMp: true,
    windowWidth: 0,
    windowHeight: 0,
    pageShow: false,
    // 上部文案控制动画
    explainAnim: '',
    // 控制展示入场动画区域
    showEntranceAnimBox: false,
    // 5张牌动画
    entranceArr: [{
      anim: ''
    }, {
      anim: ''
    }, {
      anim: ''
    }, {
      anim: ''
    }, {
      anim: ''
    }],
    // 5张牌下面文案动画
    instructionsAnim: '',
    // 控制洗牌按钮
    showShuffleTheDeckBtn: false,
    // 控制洗牌区域
    showShuffleDeckBox: false,
    // 控制牌上升动画
    showRisingAnimBox: false,
    // 控制切牌区域
    showCutBox: false,
    // 控制切牌动画区域
    showCutAnimBox: false,
    // 控制切完牌到发牌位置动画
    showMoveBox: false,
    // 控制展示发牌动画区域
    showOperatingArea: false,
    // 铺排的塔罗牌数据
    tarotData: [{
      trans: ''
    }, {
      trans: ''
    }, {
      trans: ''
    }, {
      trans: ''
    }, {
      trans: ''
    }, {
      trans: ''
    }, {
      trans: ''
    }, {
      trans: ''
    }, {
      trans: ''
    }, {
      trans: ''
    }, {
      trans: ''
    }, {
      trans: ''
    }, {
      trans: ''
    }, {
      trans: ''
    }, {
      trans: ''
    }, {
      trans: ''
    }, {
      trans: ''
    }, {
      trans: ''
    }, {
      trans: ''
    }, {
      trans: ''
    }, {
      trans: ''
    }, {
      trans: ''
    }],
    // 抽中塔罗的图片
    chooseTarotImg: '',
    // 发牌区域消失动画
    hiddenAnim: '',
    // 控制选中塔罗区域
    showChooseTarot: false,
    clickIndex: -1,
    // 控制解读按钮的展示
    showInterpretationBtn: false,
    // ---------------------------------------------详情页面的数据
    showDetailPage: false,
    shareFlag: false,
    authFlag: false,
    guideFlag: false,
    animation: '',
    shareImg: '',
    chooseTarotData: {},
    //共用
    showTimeLine: false,
    channelData: {},
    redirectConfig: {},
    templateIds: [],
    aid: '',
    bannerAlias: 'mini_daysign_banner'
  },
  onLoad: function onLoad(options) {
    var _this = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
      var redirectConfigArr;
      return _regeneratorRuntime2().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            if (options && 'aid' in options) {
              _this.setData({
                aid: options.aid
              });
            }
            if (!wx.getSystemInfoSync().isQB) {
              _this.setData({
                qbMp: false
              });
            }
            _context.next = 4;
            return app.fetchRedirectConfig({
              position: 'daily_card'
            });
          case 4:
            redirectConfigArr = _context.sent;
            if (redirectConfigArr.length > 0) {
              _this.setData({
                redirectConfig: redirectConfigArr[0]
              });
            }
            _this.fetchTemplateIds();
          case 7:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }))();
  },
  onShow: function onShow() {
    var _this2 = this;
    var that = this;
    isClick = true;
    wx.showShareMenu({
      menus: ['shareAppMessage', 'shareTimeline']
    });
    wx.getSystemInfo({
      success: function success(res) {
        _this2.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        });
      }
    });
    that.setData({
      explainAnim: '',
      showEntranceAnimBox: false,
      entranceArr: [{
        anim: ''
      }, {
        anim: ''
      }, {
        anim: ''
      }, {
        anim: ''
      }, {
        anim: ''
      }],
      instructionsAnim: '',
      showShuffleTheDeckBtn: false,
      showShuffleDeckBox: false,
      showRisingAnimBox: false,
      showCutBox: false,
      showCutAnimBox: false,
      showMoveBox: false,
      showOperatingArea: false,
      tarotData: [{
        trans: ''
      }, {
        trans: ''
      }, {
        trans: ''
      }, {
        trans: ''
      }, {
        trans: ''
      }, {
        trans: ''
      }, {
        trans: ''
      }, {
        trans: ''
      }, {
        trans: ''
      }, {
        trans: ''
      }, {
        trans: ''
      }, {
        trans: ''
      }, {
        trans: ''
      }, {
        trans: ''
      }, {
        trans: ''
      }, {
        trans: ''
      }, {
        trans: ''
      }, {
        trans: ''
      }, {
        trans: ''
      }, {
        trans: ''
      }, {
        trans: ''
      }, {
        trans: ''
      }],
      chooseTarotImg: '',
      hiddenAnim: '',
      showChooseTarot: false,
      clickIndex: -1,
      showInterpretationBtn: false,
      animateLength: 42,
      animationView: []
    });
    if (app.isLogin() && app.getAllow()) {
      var url = api.baseUrl + 'brapi/tarot/sign';
      api.fetchGet(url).then(function (res) {
        if (res.status) {
          isShare = true;
          showNum = 0;
          that.fetchDetailData();
          that.shareData();
        }
      });
    }
    // 判断今日能不能抽签了
    that.setData({
      pageShow: true
    });
    if (!wx.getSystemInfoSync().isQB) {
      wx.setNavigationBarColor({
        frontColor: '#ffffff',
        backgroundColor: '#1f244c'
      });
    }
    timeout1 = setTimeout(function () {
      that.actionFn();
    }, 3000);
    timeout2 = setTimeout(function () {
      that.setData({
        showEntranceAnimBox: true
      });
    }, 200);
  },
  onHide: function onHide() {
    clearTimeout(timeout0);
    clearTimeout(timeout1);
    clearTimeout(timeout2);
    clearTimeout(timeout3);
    clearTimeout(timeout4);
    clearTimeout(timeout5);
    clearTimeout(timeout6);
    clearTimeout(timeout7);
    clearTimeout(timeout8);
  },
  onUnload: function onUnload() {
    clearTimeout(timeout0);
    clearTimeout(timeout1);
    clearTimeout(timeout2);
    clearTimeout(timeout3);
    clearTimeout(timeout4);
    clearTimeout(timeout5);
    clearTimeout(timeout6);
    clearTimeout(timeout7);
    clearTimeout(timeout8);
  },
  // 洗牌前 判断今日能不能抽签了
  fetchTarotStatus: function fetchTarotStatus() {
    var that = this;
    var url = api.baseUrl + 'brapi/tarot/sign';
    // that.shuffleDeckFn()
    if (app.checkLoginStatus()) {
      api.fetchGet(url).then(function (res) {
        if (res.status) {
          isShare = true;
          showNum = 0;
          that.fetchDetailData();
          that.shareData();
        } else {
          that.shuffleDeckFn();
        }
      });
    }
  },
  actionFn: function actionFn() {
    var that = this;
    clearTimeout(timeout1);
    var entranceArr = that.data.entranceArr;
    if (entranceArr[0].anim) return;
    entranceArr.forEach(function (v, k) {
      v.anim = 'entranceAnimImg' + k;
    });
    that.setData({
      explainAnim: 'explainAnim',
      entranceArr: entranceArr,
      instructionsAnim: 'instructionsAnim'
    });
    timeout3 = setTimeout(function () {
      that.setData({
        showShuffleTheDeckBtn: true
      });
    }, 1500);
  },
  getRandomNumber: function getRandomNumber(lower, upper, n) {
    var arr = [];
    for (var i = 0; i < n; i++) {
      var number = Math.random() * (upper - lower + 1) + lower;
      if (arr.indexOf(number) < 0) {
        arr.push(number);
      } else {
        i--;
      }
    }
    return arr;
  },
  setStep2ImageAni: function setStep2ImageAni() {
    var that = this;
    var arr = new Array(this.data.animateLength).join(',').split(',');
    var animationView = arr.map(function (item, index) {
      return that.setItemAni();
    });
    return animationView;
  },
  setItemAni: function setItemAni() {
    var that = this;
    var arr = that.getRandomNumber(-120, 230, 4);
    var rotate = that.getRandomNumber(-180, 180, 2);
    var animation = wx.createAnimation({
      duration: 3200,
      transformOrigin: '-10% center 0',
      timingFunction: 'ease'
    });
    animation.translateX(arr[0]).translateY(arr[1]).rotate(rotate[0]).step({
      duration: 800
    }).translateX(0).translateY(0).rotate(0).step({
      duration: 800
    }).translateX(arr[2]).translateY(arr[3]).rotate(rotate[1]).step({
      duration: 800
    }).translateX(0).translateY(0).rotate(0).step({
      duration: 800
    });
    return animation;
  },
  shuffleDeckFn: function shuffleDeckFn() {
    var that = this;
    that.setData({
      showEntranceAnimBox: false,
      showShuffleDeckBox: true
    });
    var animationView = that.setStep2ImageAni();
    setTimeout(function () {
      that.setData({
        animationView: animationView.map(function (item) {
          return item.export();
        })
      });
    }, 10);
    timeout4 = setTimeout(function () {
      that.setData({
        showShuffleDeckBox: false,
        showOperatingArea: true
      });
    }, 4000);
  },
  cutFn: function cutFn() {
    var that = this;
    that.setData({
      showCutBox: false,
      showCutAnimBox: true
    });
    timeout6 = setTimeout(function () {
      that.setData({
        showCutAnimBox: false,
        showMoveBox: true
      });
    }, 2500);
    timeout7 = setTimeout(function () {
      that.setData({
        showMoveBox: false,
        showOperatingArea: true
      });
    }, 3500);
  },
  choose: function choose(e) {
    var that = this;
    var tarotData = that.data.tarotData;
    var index = e.currentTarget.dataset.index;
    if (!isClick) {
      console.log('不能点击了');
      return;
    }
    ;
    isClick = false;
    // 给选中的塔罗加动画
    tarotData[index].trans = 'removeAnim';
    that.setData({
      tarotData: tarotData,
      hiddenAnim: 'hiddenAnim',
      showChooseTarot: true
    });
    // 获取抽签的数据
    that.fetchData(function () {
      timeout8 = setTimeout(function () {
        that.setData({
          showOperatingArea: false,
          showInterpretationBtn: true
        });
      }, 2500);
    });
  },
  fetchData: function fetchData(cb) {
    var that = this;
    var url = api.baseUrl + 'brapi/tarot/detail';
    api.fetchGet(url).then(function (res) {
      that.setData({
        chooseTarotData: res
      });
      cb();
    });
  },
  fetchTemplateIds: function fetchTemplateIds() {
    var that = this;
    api.fetchGet(api.baseUrl + 'wxapp/templateIds', {
      business: 'check_in_reminder'
    }).then(function (res) {
      that.setData({
        templateIds: res.templateIds
      });
    });
  },
  submitFormid2: function submitFormid2() {
    var that = this;
    var business_id = app.globalData.userInfo.uid;
    app.applySubMsg(this.data.templateIds, business_id, function () {
      isShare = true;
      showNum = 0;
      that.fetchDetailData(1);
      that.shareData();
    });
  },
  /**
   * 以下是展示的详情页的内容
   */
  onShareAppMessage: function onShareAppMessage(res) {
    var that = this;
    console.log(res.target);
    console.log(that.data.shareImg);
    that.setData({
      shareFlag: false
    });
    return {
      title: '来自阿卡纳的神秘指引...',
      path: 'pages/tarotSignIn/index',
      imageUrl: that.data.shareImg
    };
  },
  onShareTimeline: function onShareTimeline() {
    return {
      title: '来自阿卡纳的神秘指引...'
    };
  },
  noclose: function noclose() {
    return;
  },
  fetchDetailData: function fetchDetailData(isClick) {
    var that = this;
    var url = api.baseUrl + 'brapi/tarot/detail';
    api.fetchGet(url).then(function (res) {
      that.setData({
        chooseTarotData: res,
        showDetailPage: true
      });
      if (!wx.getSystemInfoSync().isQB) {
        wx.setNavigationBarColor({
          frontColor: '#ffffff',
          backgroundColor: '#1f244c'
        });
      }
      that.drawImageFn(res.tarotId);
      if (!wx.getStorageSync('ShowGuide')) {
        setTimeout(function () {
          that.setData({
            guideFlag: true
          });
          setTimeout(function () {
            if (that.data.windowHeight > 667 && that.data.windowWidth <= 375) {
              // 适配大屏手机
              that.setData({
                animation: 'promptBgAnim1'
              });
            } else {
              // 适配iPhone7
              that.setData({
                animation: 'promptBgAnim2'
              });
            }
          }, 400);
        }, 2000);
      }
      if (isClick && res.tips) {
        wx.showModal({
          title: '提示',
          showCancel: false,
          content: res.tips,
          success: function success(res) {}
        });
      }
    });
  },
  shareData: function shareData() {
    var that = this;
    var url = api.baseUrl + 'store/weapp/share';
    api.fetchGet(url, {
      noTip: true
    }).then(function (res) {
      that.setData({
        showTimeLine: res.showTimeLine
      });
    });
  },
  shareFn: function shareFn() {
    this.setData({
      shareFlag: !this.data.shareFlag
    });
  },
  authFn: function authFn() {
    this.setData({
      authFlag: !this.data.authFlag
    });
  },
  guideFn: function guideFn() {
    wx.setStorageSync('ShowGuide', true);
    this.setData({
      guideFlag: false
    });
  },
  showAuthListFn: function showAuthListFn(e) {
    var that = this;
    that.setData({
      authFlag: false
    });
    if (e.detail.authSetting['scope.writePhotosAlbum']) {
      that.saveImage();
    }
  },
  drawImageFn: function drawImageFn(tarotId) {
    var that = this;
    var url = 'https://static.shengri.cn/uploads/PMSelfService/manager/moments/miniProgram/tarot/screenshots0815/' + tarotId + '.png';
    var chooseTarotData = that.data.chooseTarotData;
    that.downloadImg(url, function (filePath) {
      // console.log(filePath);
      var ctx = wx.createCanvasContext('shareCanvas');
      ctx.drawImage(filePath, 0, 0, 375 * Amultiple, 375 * 1.77 * Amultiple);
      setTimeout(function () {
        // 农历
        ctx.setFillStyle('#FBD858');
        ctx.setFontSize(20);
        ctx.fillText('农历' + chooseTarotData.lunar_date, 62, 174);
        ctx.stroke();
        // 日期，日
        ctx.setTextAlign('center');
        ctx.setFillStyle('#FBD858');
        ctx.setFontSize(44);
        ctx.fillText(chooseTarotData.day, 654, 168);
        ctx.stroke();

        // 日期，月
        ctx.setFillStyle('#FBD858');
        ctx.setFontSize(24);
        ctx.fillText(chooseTarotData.month, 577, 140);
        ctx.stroke();

        // 日期，年
        ctx.setFillStyle('#FBD858');
        ctx.setFontSize(24);
        ctx.fillText(chooseTarotData.year, 577, 176);
        ctx.stroke();
        ctx.draw(true, function () {
          wx.canvasToTempFilePath({
            canvasId: 'shareCanvas',
            success: function success(res) {
              console.log('保存生成的图片');
              console.log(res.tempFilePath);
              that.setData({
                shareImg: res.tempFilePath
              });
            },
            fail: function fail(err) {
              console.log(err);
            },
            complete: function complete() {}
          });
        });
      }, 300);
    });
  },
  saveImage: function saveImage() {
    var that = this;
    that.setData({
      shareFlag: false
    });
    if (!isShare) return;
    isShare = false;
    wx.saveImageToPhotosAlbum({
      filePath: that.data.shareImg,
      success: function success(resp) {
        isShare = true;
        wx.showModal({
          title: '图片已保存至相册',
          content: '由于系统限制，需要您手动分享至朋友圈',
          showCancel: false,
          success: function success(res) {}
        });
      },
      fail: function fail() {
        isShare = true;
        wx.getSetting({
          success: function success(res) {
            if (res.authSetting['scope.writePhotosAlbum']) {
              if (showNum < 3) {
                wx.showModal({
                  title: '保存失败',
                  content: '由于未知原因，保存图片失败，重试一次也许可以解决问题。',
                  cancelText: '下次再说',
                  confirmText: '重试一次',
                  success: function success(res) {
                    if (res.confirm) {
                      console.log('用户点击确定');
                      that.saveImage();
                    } else if (res.cancel) {
                      console.log('用户点击取消');
                    }
                  }
                });
              } else {
                wx.showModal({
                  title: '还是不行鸭🐥',
                  content: '很抱歉，看来这很可能是个重试也解决不了的问题。',
                  cancelText: '下次再说',
                  confirmText: '重试一次',
                  success: function success(res) {
                    if (res.confirm) {
                      console.log('用户点击确定');
                      that.saveImage();
                    } else if (res.cancel) {
                      console.log('用户点击取消');
                    }
                  }
                });
              }
              showNum += 1;
            } else {
              that.setData({
                authFlag: true
              });
            }
          }
        });
      }
    });
  },
  downloadImg: function downloadImg(path, cb) {
    var that = this;
    wx.downloadFile({
      url: path,
      success: function success(res) {
        var tempFilePath = res.tempFilePath;
        cb(tempFilePath);
      },
      fail: function fail() {
        // wx.hideLoading()
        wx.showToast({
          title: '生成失败',
          icon: 'loading',
          duration: 1500
        });
      }
    });
  },
  goIndex: function goIndex() {
    var redirectConfig = this.data.redirectConfig;
    wx.navigateToMiniProgram({
      appId: redirectConfig.wxAppId,
      path: redirectConfig.path ? redirectConfig.path : 'pages/index/index',
      extraData: {},
      envVersion: 'trial',
      success: function success(res) {}
    });
  }
});