var api = require('./../../utils/api.js');var app = getApp();Page({
  data: {
    windowWidth: 0,
    windowHeight: 0
  },
  onLoad: function onLoad(options) {},
  onShow: function onShow() {
    var _this = this;
    wx.getSystemInfo({
      success: function success(res) {
        _this.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        });
      }
    });
  }
});