var api = require("./../../utils/api.js");var app = getApp();Page({
  data: {
    list: [],
    page: 0,
    isMore: true,
    showDeleteBox: false,
    postIds: []
  },
  onLoad: function onLoad(options) {},
  onShow: function onShow() {
    var _this = this;
    // 没登录去登陆
    var isLogin = app.isLogin();
    wx.getSystemInfo({
      success: function success(res) {
        _this.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        });
      }
    });
    this.setData({
      page: 0,
      isMore: true
    });
    if (isLogin) {
      this.fetchData();
    }
  },
  onReady: function onReady() {},
  onHide: function onHide() {},
  onUnload: function onUnload() {},
  onReachBottom: function onReachBottom() {
    this.fetchMore();
  },
  fetchData: function fetchData() {
    var that = this;
    var isMore = that.data.isMore;
    var page = that.data.page;
    wx.showToast({
      title: "加载中...",
      icon: "loading",
      duration: 10000
    });
    api.fetchGet(api.baseUrl + "ask/userQuestionList", {
      limit: 10,
      page: that.data.page
    }).then(function (res) {
      wx.hideToast();
      if (res.items.length < 10) {
        isMore = false;
      } else {
        page += 1;
      }
      that.setData({
        page: page,
        list: res.items,
        isMore: isMore
      });
    });
  },
  fetchMore: function fetchMore() {
    var that = this;
    var isMore = that.data.isMore;
    var page = that.data.page;
    if (!isMore) {
      return;
    }
    wx.showToast({
      title: "加载中...",
      icon: "loading",
      duration: 10000
    });
    api.fetchGet(api.baseUrl + "ask/userQuestionList", {
      limit: 10,
      page: that.data.page
    }).then(function (res) {
      wx.hideToast();
      if (res.items.length < 10) {
        isMore = false;
      } else {
        page += 1;
      }
      that.setData({
        isMore: isMore,
        page: page,
        list: that.data.list.concat(res.items)
      });
    });
  },
  goDetail: function goDetail(e) {
    var postId = e.currentTarget.dataset.postid;
    wx.navigateTo({
      url: "../detail/index?postId=" + postId
    });
  },
  goIndexFn: function goIndexFn() {
    // wx.redirectTo({url: '../index/index'})
    // 如果没有登录，就去登录授权
    var isLogin = app.isLogin();
    if (!isLogin) {
      if (app.getAllow()) {
        wx.navigateTo({
          url: "../login/login"
        });
      } else {
        wx.navigateTo({
          url: "../authorization/authorization"
        });
      }
      return;
    }
    // wx.navigateBack({
    //   delta: 1
    // })
    wx.navigateTo({
      url: "../tarotGame/index"
    });
  },
  //删除提问
  handleDeleteQuestion: function handleDeleteQuestion(e) {
    var that = this;
    var postIds = [];
    postIds.push(e.currentTarget.dataset.postid);
    // console.log("postIds", postIds);

    that.setData({
      showDeleteBox: true,
      postIds: postIds
    });
  },
  handleSure: function handleSure() {
    var _this2 = this;
    var that = this;
    api.fetchPost(api.baseUrl + "ask/posts/delete", {
      post_ids: that.data.postIds
    }).then(function (res) {
      if (!res.status) {
        that.data.list.forEach(function (v, k) {
          if (v.post_id == that.data.postIds[0]) {
            that.data.list.splice(k, 1);
          }
        });
      }
      _this2.setData({
        showDeleteBox: false,
        list: that.data.list,
        postIds: []
      });
      wx.showToast({
        title: res.message,
        icon: "none",
        duration: 1500
      });
    });
  },
  handleCancelDelete: function handleCancelDelete() {
    this.setData({
      showDeleteBox: false
    });
  }
});