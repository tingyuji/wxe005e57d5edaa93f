var _defineProperty2 = require("../../@babel/runtime/helpers/defineProperty");var _toConsumableArray2 = require("../../@babel/runtime/helpers/toConsumableArray");var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var _Page;var timer;var innerAudioContext;var api = require("./../../utils/api.js");var app = getApp();var isLoading = false;Page((_Page = {
  data: {
    bullet: ["我表白会成功吗", "他为什么不主动找我聊天了", "我喜欢的人喜欢我吗", "我答应和他复合会幸福吗", "他会来找我复合吗", "他是不是真的喜欢我", "我会和他在一起到结婚吗", "我和他应该离婚吗", "我原谅他后会和以前一样吗", "分手后他有想过我吗", "我什么时候能脱单", "分手了怎么才能让对方主动复合", "他是不是出轨了"],
    commentsData: [{
      avatar: "https://cdn1.shengri.cn/MjQ1NTI0MTY=/aF8xNTM5MTM1MzkyMDQ0XzEzNTM=.jpg",
      nickname: "小七仔0621",
      cert_name: "塔罗达人",
      cert_level_id: 4,
      created_at_hm: "1小时前",
      price: 400,
      audio_mins: 51,
      audio_url: "https://static.shengri.cn/uploads/xydd/web/m/ask/Y18xNTUwMjEwMzk4NzExXzMwOTg=.m4a",
      currentText: "",
      isPlay: false,
      comment_id: "111111"
    }, {
      avatar: "https://cdn1.shengri.cn/MjQ1NTM2NTM/aF8xNTQyODY5Njk3MTU0XzQwNjk.jpg",
      nickname: "咨询师-阿唯",
      cert_name: "塔罗达人",
      cert_level_id: 5,
      created_at_hm: "1小时前",
      price: 500,
      audio_mins: 44,
      audio_url: "https://static.shengri.cn/uploads/xydd/web/m/ask/Y18xNTUwMjEwNTQ5NTU2XzE5NTU=.m4a",
      currentText: "",
      isPlay: false,
      comment_id: "222222"
    }],
    clickIndex: "",
    //用于传递
    currentIndex: -1,
    //用于判断
    currentTab: 0,
    typeTitle: [],
    // recommendList: [], //推荐
    // popularityList: [], //人气
    // newPersonList: [], //新人
    dataList: [],
    windowHeight: "",
    anim: "",
    //+1的动画
    is_follow: 0,
    hasAdd: false,
    isMore: true,
    page: 1
  },
  componentContext: function componentContext(e) {
    console.log("e------------>", e.detail);
  },
  handleTab: function handleTab(e) {
    this.setData({
      currentTab: e.currentTarget.dataset.current
    });
  },
  //复制粘贴
  handleCopy: function handleCopy() {
    wx.setClipboardData({
      data: "http://6ds.me/pCZ5R",
      success: function success(result) {
        wx.getClipboardData({
          success: function success(res) {}
        });
      }
    });
  },
  //根据type值获取推荐/人气/新人对应的达人信息
  // getChatRecommendList() {
  //   let that = this;
  //   let type = [9, 10, 11];
  //   for (let i = 0; i < type.length; i++) {
  //     api
  //       .fetchGet(api.baseUrl + "ask/chat/recommend_list", {
  //         type: type[i],
  //         page: 0,
  //         limit: 10,
  //       })
  //       .then((res) => {
  //         if (type[i] == 9) {
  //           that.setData({
  //             popularityList: res.items,
  //           });
  //         } else if (type[i] == 10) {
  //           that.setData({
  //             newPersonList: res.items,
  //           });
  //         } else if (type[i] == 11) {
  //           that.setData({
  //             recommendList: res.items,
  //           });
  //         }
  //       });
  //   }
  // },
  //  加载更多
  // fetchRecommendDataMore() {
  //   let that = this;
  //   let page = that.data.page;
  //   let isMore = that.data.isMore;
  //   if (!isMore) {
  //     return;
  //   }
  //   wx.showToast({
  //     title: "加载中...",
  //     icon: "loading",
  //     duration: 1000,
  //   });
  //   api
  //     .fetchGet(api.baseUrl + "ask/chat/recommend_list", {
  //       type: 11,
  //       page: page,
  //     })
  //     .then((res) => {
  //       wx.hideLoading();
  //       if (res.items.length < 10) {
  //         isMore = false;
  //       } else {
  //         page += 1;
  //       }
  //       let data = that.data.recommendList.concat(res.items);
  //       console.log(page, res.items, data);
  //       that.setData({
  //         page: page,
  //         isMore: isMore,
  //         recommendList: data,
  //       });
  //     });
  // },
  // fetchPopularDataMore() {
  //   let that = this;
  //   let page = that.data.page;
  //   let isMore = that.data.isMore;
  //   if (!isMore) {
  //     return;
  //   }
  //   wx.showToast({
  //     title: "加载中...",
  //     icon: "loading",
  //     duration: 1000,
  //   });
  //   api
  //     .fetchGet(api.baseUrl + "ask/chat/recommend_list", {
  //       type: 9,
  //       page: page,
  //     })
  //     .then((res) => {
  //       wx.hideLoading();
  //       if (res.items.length < 10) {
  //         isMore = false;
  //       } else {
  //         page += 1;
  //       }
  //       let data = that.data.popularityList.concat(res.items);
  //       that.setData({
  //         page: page,
  //         isMore: isMore,
  //         popularityList: data,
  //       });
  //     });
  // },
  // fetchNewPersonDataMore() {
  //   let that = this;
  //   let page = that.data.page;
  //   let isMore = that.data.isMore;
  //   if (!isMore) {
  //     return;
  //   }
  //   wx.showToast({
  //     title: "加载中...",
  //     icon: "loading",
  //     duration: 1000,
  //   });
  //   api
  //     .fetchGet(api.baseUrl + "ask/chat/recommend_list", {
  //       type: 10,
  //       page: page,
  //     })
  //     .then((res) => {
  //       wx.hideLoading();
  //       if (res.items.length < 10) {
  //         isMore = false;
  //       } else {
  //         page += 1;
  //       }
  //       let data = that.data.newPersonList.concat(res.items);
  //       that.setData({
  //         page: page,
  //         isMore: isMore,
  //         newPersonList: data,
  //       });
  //     });
  // },
  onShow: function onShow() {
    var _this = this;
    var that = this;
    this.getChatType();
    innerAudioContext = wx.createInnerAudioContext();
    innerAudioContext.onPlay(function () {
      that.audioOnPlay();
    });
    innerAudioContext.onEnded(function () {
      that.audioOnEnded();
    });
    var res = wx.getSystemInfoSync();
    that.setData({
      windowHeight: res.windowHeight - 50 - 76 - 30 - 100
    });
    setTimeout(function () {
      _this.getChatRecommendList();
    });
  },
  // playAudio(e) {
  //   let that = this;
  //   let index = e.currentTarget.dataset.index;
  //   let commendId = e.currentTarget.dataset.commentid;
  //   let currentIndex = that.data.currentIndex;
  //   let commentsData = that.data.commentsData;
  //   let audio = commentsData[index].audio_url;
  //   //判断currentIndex与index是否相等
  //   if (currentIndex === index) {
  //     if (commentsData[index].isPlay) {
  //       console.log("1");
  //       commentsData[index].isPlay = false;
  //       commentsData[index].currentText = "已暂停";
  //       innerAudioContext.pause();
  //     } else {
  //       console.log("2");
  //       commentsData[index].isPlay = true;
  //       commentsData[index].currentText = "正在播放";
  //       innerAudioContext.play();
  //     }
  //     this.setData({
  //       commentsData: commentsData,
  //     });
  //   } else {
  //     console.log("3");
  //     commentsData.forEach((v, k) => {
  //       commentsData[k].isPlay = false;
  //       commentsData[k].currentText = null;
  //     });
  //     innerAudioContext.src = audio;
  //     innerAudioContext.play();
  //     this.setData({
  //       commentsData: commentsData,
  //       currentIndex: index,
  //     });
  //   }
  //   that.setData({
  //     clickIndex: index,
  //   });
  // },
  // audioOnPlay() {
  //   let clickIndex = this.data.clickIndex;
  //   let commentsData = this.data.commentsData;
  //   commentsData[clickIndex].isPlay = true;
  //   commentsData[clickIndex].currentText = "正在播放";
  //   this.setData({
  //     commentsData: commentsData,
  //   });
  // },
  // audioOnEnded() {
  //   let clickIndex = this.data.clickIndex;
  //   let commentsData = this.data.commentsData;
  //   commentsData[clickIndex].isPlay = false;
  //   commentsData[clickIndex].currentText = null;
  //   this.setData({
  //     commentsData: commentsData,
  //   });
  // },
  handleFollow: function handleFollow() {
    var is_follow = !this.data.is_follow;
    var anim = "anim";
    this.setData({
      is_follow: is_follow,
      anim: anim,
      hasAdd: true
    });
  },
  handleBindChange: function handleBindChange(e) {
    this.setData({
      current: e.detail.current
    });
  },
  swiperChange: function swiperChange(e) {
    var typeTitle = this.data.typeTitle;
    this.setData({
      currentTab: e.detail.current
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    var _this2 = this;
    //获取高度
    var res = wx.getSystemInfoSync();
    this.setData({
      windowHeight: res.windowHeight - 204
    });

    //播放语音
    innerAudioContext = wx.createInnerAudioContext();
    innerAudioContext.onPlay(function () {
      _this2.audioOnPlay();
    });
    innerAudioContext.onEnded(function () {
      _this2.audioOnEnded();
    });
  },
  //根据type值获取推荐/人气/新人对应的达人信息
  getChatRecommendList: function getChatRecommendList() {
    var _this3 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
      var that, typeTitle, array, result;
      return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            that = _this3;
            typeTitle = that.data.typeTitle;
            console.log("start");
            array = typeTitle.map( /*#__PURE__*/function () {
              var _ref = _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee(v, i) {
                var res, data;
                return _regeneratorRuntime2().wrap(function _callee$(_context) {
                  while (1) switch (_context.prev = _context.next) {
                    case 0:
                      _context.prev = 0;
                      _context.next = 3;
                      return api.fetchGet(api.baseUrl + "ask/chat/recommend_list", {
                        type: typeTitle[i].type,
                        page: 0,
                        limit: 10
                      });
                    case 3:
                      res = _context.sent;
                      console.log("1111111111");
                      console.log(typeTitle[i].type);
                      console.log("22222222222");
                      console.log("3333333333");
                      data = {};
                      data.items = res.items;
                      data.type = typeTitle[i].type;
                      return _context.abrupt("return", data);
                    case 14:
                      _context.prev = 14;
                      _context.t0 = _context["catch"](0);
                    case 16:
                    case "end":
                      return _context.stop();
                  }
                }, _callee, null, [[0, 14]]);
              }));
              return function (_x, _x2) {
                return _ref.apply(this, arguments);
              };
            }());
            console.log("array", array);
            console.log("end");
            _context2.next = 8;
            return Promise.all(array);
          case 8:
            result = _context2.sent;
            console.log(result);
            that.setData({
              dataList: result
            });
          case 11:
          case "end":
            return _context2.stop();
        }
      }, _callee2);
    }))();
  },
  // fetchRecommendMore(type) {
  //   let that = this;
  //   let page = that.data.RePage;
  //   let isMore = that.data.ReIsMore;
  //   let list = that.data.dataList;
  //   if (!isMore) {
  //     return;
  //   }
  //   wx.showToast({
  //     title: "加载中...",
  //     icon: "loading",
  //     duration: 1000,
  //   });
  //   api
  //     .fetchGet(api.baseUrl + "ask/chat/recommend_list", {
  //       type: type,
  //       page: page,
  //     })
  //     .then((res) => {
  //       wx.hideLoading();
  //       if (JSON.stringify(res) === "{}") {
  //         // isMore = false;
  //         return this.setData({
  //           ReIsMore: false,
  //         });
  //       }
  //       if (res.items.length < 10) {
  //         isMore = false;
  //       } else {
  //         page += 1;
  //       }
  //       list.forEach((v, k) => {
  //         if (v.type === type) {
  //           v.items = v.items.concat(res.items);
  //         }
  //       });
  //       that.setData({
  //         RePage: page,
  //         ReIsMore: isMore,
  //         dataList: list,
  //       });
  //     });
  // },
  // fetchPopularMore(type) {
  //   let that = this;
  //   let page = that.data.PoPage;
  //   let isMore = that.data.PoIsMore;
  //   let list = that.data.dataList;
  //   if (!isMore) {
  //     return;
  //   }
  //   wx.showToast({
  //     title: "加载中...",
  //     icon: "loading",
  //     duration: 1000,
  //   });
  //   api
  //     .fetchGet(api.baseUrl + "ask/chat/recommend_list", {
  //       type: type,
  //       page: page,
  //     })
  //     .then((res) => {
  //       wx.hideLoading();
  //       if (JSON.stringify(res) == "{}") {
  //         //isMore = false;
  //         return this.setData({
  //           PoIsMore: false,
  //         });
  //       }
  //       if (res.items.length < 10) {
  //         isMore = false;
  //       } else {
  //         page += 1;
  //       }
  //       list.forEach((v, k) => {
  //         if (v.type == type) {
  //           v.items = v.items.concat(res.items);
  //         }
  //       });
  //       that.setData({
  //         PoPage: page,
  //         PoIsMore: isMore,
  //         dataList: list,
  //       });
  //     });
  // },
  // fetchNewMore(type) {
  //   let that = this;
  //   let page = that.data.NewPage;
  //   let isMore = that.data.NewIsMore;
  //   let list = that.data.dataList;
  //   if (!isMore) {
  //     return;
  //   }
  //   wx.showToast({
  //     title: "加载中...",
  //     icon: "loading",
  //     duration: 1000,
  //   });
  //   api
  //     .fetchGet(api.baseUrl + "ask/chat/recommend_list", {
  //       type: type,
  //       page: page,
  //     })
  //     .then((res) => {
  //       wx.hideLoading();
  //       if (JSON.stringify(res) == "{}") {
  //         // isMore = false;
  //         return this.setData({
  //           NewIsMore: false,
  //         });
  //       }
  //       if (res.items.length < 10) {
  //         isMore = false;
  //       } else {
  //         page += 1;
  //       }
  //       list.forEach((v, k) => {
  //         if (v.type == type) {
  //           v.items = v.items.concat(res.items);
  //         }
  //       });
  //       that.setData({
  //         NewPage: page,
  //         NewIsMore: isMore,
  //         dataList: list,
  //       });
  //     });
  // },
  // 点击播放语音
  playAudio: function playAudio(e) {
    var that = this;
    var listidx = that.data.currentTab;
    var index = e.currentTarget.dataset.index;
    var currentIndex = that.data.currentIndex;
    var list = that.data.dataList;
    var audio = list[listidx].items[index].audio.audio_url;
    var itemsData = list[listidx].items;
    if (currentIndex === index) {
      if (itemsData[index].isPlay) {
        itemsData[index].isPlay = false;
        innerAudioContext.stop();
      } else {
        itemsData[index].isPlay = true;
        innerAudioContext.play();
      }
      this.setData({
        dataList: list
      });
    } else {
      itemsData.forEach(function (v, k) {
        itemsData[k].isPlay = false;
      });
      innerAudioContext.src = audio;
      innerAudioContext.play();
      that.setData({
        dataList: list,
        currentIndex: index
      });
    }
    that.setData({
      clickIndex: index,
      listIndex: listidx
    });
  },
  audioOnPlay: function audioOnPlay() {
    var clickIndex = this.data.clickIndex;
    var listidx = this.data.listIndex;
    var list = this.data.dataList;
    var itemsData = list[listidx].items;
    itemsData[clickIndex].isPlay = true;
    this.setData({
      dataList: list
    });
  },
  audioOnEnded: function audioOnEnded() {
    var clickIndex = this.data.clickIndex;
    var listidx = this.data.listIndex;
    var list = this.data.dataList;
    var itemsData = list[listidx].items;
    itemsData[clickIndex].isPlay = false;
    this.setData({
      dataList: list
    });
  },
  onUnload: function onUnload() {
    innerAudioContext.stop();
    innerAudioContext.destroy();
    clearTimeout(timer);
  },
  onHide: function onHide() {
    clearTimeout(timer);
  }
}, _defineProperty2(_Page, "onUnload", function onUnload() {
  innerAudioContext.stop();
  innerAudioContext.destroy();
  clearTimeout(timer);
}), _defineProperty2(_Page, "getChatType", function getChatType() {
  var _this4 = this;
  return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3() {
    var that, _yield$api$fetchGet, items, data;
    return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
      while (1) switch (_context3.prev = _context3.next) {
        case 0:
          that = _this4;
          _context3.prev = 1;
          _context3.next = 4;
          return api.fetchGet(api.baseUrl + "ask/chat/filters");
        case 4:
          _yield$api$fetchGet = _context3.sent;
          items = _yield$api$fetchGet.items;
          //初始化datalist
          data = items.map(function (v, k) {
            return {
              items: [],
              page: 0,
              isMore: true,
              type: v.type
            };
          });
          that.setData({
            typeTitle: items,
            dataList: data
          });
          that.handleFresh();
          _context3.next = 13;
          break;
        case 11:
          _context3.prev = 11;
          _context3.t0 = _context3["catch"](1);
        case 13:
        case "end":
          return _context3.stop();
      }
    }, _callee3, null, [[1, 11]]);
  }))();
}), _defineProperty2(_Page, "handleFresh", function handleFresh() {
  var _this5 = this;
  return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee4() {
    var that, currentIndex, dataList, oldData, newData;
    return _regeneratorRuntime2().wrap(function _callee4$(_context4) {
      while (1) switch (_context4.prev = _context4.next) {
        case 0:
          that = _this5; //当前索引
          currentIndex = _this5.data.currentTab;
          dataList = _this5.data.dataList; //获取当前索引对应的对象
          oldData = dataList[currentIndex]; //没有更多加载数据时，中断请求
          if (oldData.isMore) {
            _context4.next = 6;
            break;
          }
          return _context4.abrupt("return");
        case 6:
          if (!isLoading) {
            _context4.next = 8;
            break;
          }
          return _context4.abrupt("return");
        case 8:
          _context4.next = 10;
          return that.fetchMore(oldData);
        case 10:
          newData = _context4.sent;
          console.log(newData);
          dataList[currentIndex] = newData;
          _this5.setData({
            dataList: dataList
          });
        case 14:
        case "end":
          return _context4.stop();
      }
    }, _callee4);
  }))();
}), _defineProperty2(_Page, "fetchMore", function fetchMore(params) {
  var _this6 = this;
  return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee5() {
    var that, _JSON$parse, type, items, page, isMore, res, v;
    return _regeneratorRuntime2().wrap(function _callee5$(_context5) {
      while (1) switch (_context5.prev = _context5.next) {
        case 0:
          that = _this6; //实现对象深拷贝
          _JSON$parse = JSON.parse(JSON.stringify(params)), type = _JSON$parse.type, items = _JSON$parse.items, page = _JSON$parse.page, isMore = _JSON$parse.isMore;
          isLoading = true;
          _context5.prev = 3;
          _context5.next = 6;
          return api.fetchGet(api.baseUrl + "ask/chat/recommend_list", {
            type: type,
            page: page
          });
        case 6:
          res = _context5.sent;
          v = res.items.length < 10;
          items = page === 0 ? res.items : [].concat(_toConsumableArray2(items), _toConsumableArray2(res.items));
          console.log("fetch items", items);
          if (v) {
            isMore = false;
          } else {
            page = page + 1;
          }
          return _context5.abrupt("return", {
            type: type,
            items: items,
            page: page,
            isMore: isMore
          });
        case 14:
          _context5.prev = 14;
          _context5.t0 = _context5["catch"](3);
        case 16:
          _context5.prev = 16;
          isLoading = false;
          return _context5.finish(16);
        case 19:
        case "end":
          return _context5.stop();
      }
    }, _callee5, null, [[3, 14, 16, 19]]);
  }))();
}), _defineProperty2(_Page, "handleTitle", function handleTitle(e) {
  var current = e.currentTarget.dataset.current;
  var dataList = this.data.dataList;
  var currentTab = this.data.currentTab;
  if (current === currentTab) return;
  console.log("dataList[current]", dataList[current]);
  var currentList = dataList[current].items;
  this.setData({
    currentTab: current
  });
  if (currentList.length <= 0) {
    this.handleFresh();
  }
}), _defineProperty2(_Page, "catchTouchMove", function catchTouchMove(res) {
  return false;
}), _defineProperty2(_Page, "handleToDownLoad", function handleToDownLoad() {
  wx.navigateTo({
    url: "../leadDownload/index"
  });
}), _Page));