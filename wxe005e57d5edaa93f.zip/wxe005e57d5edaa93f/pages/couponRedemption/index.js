var api = require("./../../utils/api.js");var app = getApp();Page({
  data: {
    windowWidth: 0,
    windowHeight: 0,
    pageData: {},
    signStatus: 0,
    addMiniStatus: false,
    showDownloadPrompt: false,
    downloadPromptText: "您即将跳转客服回话，回复'下载'即可",
    templateIds: [],
    couponTip: ""
  },
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: "无限次免费问感情事业等问题，专业占卜师在线解惑",
      path: "pages/index/index?inviteUserId=" + app.globalData.userInfo.uid,
      imageUrl: "https://static.shengri.cn/uploads/QA_mp/InvitedShare@2x-1.png?imageslim"
    };
  },
  onLoad: function onLoad(options) {
    var addMiniStatus = wx.getStorageSync("addMiniStatus") || false;
    console.log(addMiniStatus);
    this.setData({
      addMiniStatus: addMiniStatus
    });
  },
  onShow: function onShow() {
    var _this = this;
    wx.getSystemInfo({
      success: function success(res) {
        _this.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        });
      }
    });
    this.fetchCouponNum();
    this.fetchSignStatus();
    this.fetchTemplateIds();
    this.fetchCouponTip();
  },
  fetchSignStatus: function fetchSignStatus() {
    var that = this;
    api.fetchGet(api.baseUrl + "brapi/tarot/sign", {}).then(function (res) {
      that.setData({
        signStatus: res.status
      });
    });
  },
  fetchCouponNum: function fetchCouponNum() {
    var that = this;
    api.fetchGet(api.baseUrl + "ask/invite/lists", {}).then(function (res) {
      that.setData({
        pageData: res
      });
      if (res.add_mini.status === 1) {
        that.setData({
          addMiniStatus: true
        });
        console.log(that.data.addMiniStatus);
      }
    });
  },
  postAddMini: function postAddMini() {
    var that = this;
    var pageData = this.data.pageData;
    api.fetchPost(api.baseUrl + "ask/coupon", {
      type: "add_mini"
    }).then(function (res) {
      that.setData({
        isShowGuide: false
      });
      if (res.msg === "success") {
        wx.showToast({
          title: "添加完成后，提问券将在1分钟后发放～",
          icon: "none",
          duration: 2000
        });
        wx.setStorageSync("addMiniStatus", true);
        pageData.add_mini.status = 1;
        that.setData({
          addMiniStatus: true,
          pageData: pageData
        });
      }
    });
  },
  showPrompt: function showPrompt() {
    this.setData({
      showDownloadPrompt: true
    });
  },
  cancel: function cancel() {
    this.setData({
      showDownloadPrompt: false
    });
  },
  fetchTemplateIds: function fetchTemplateIds() {
    var that = this;
    api.fetchGet(api.baseUrl + "wxapp/templateIds", {
      business: "check_in_reminder"
    }).then(function (res) {
      that.setData({
        templateIds: res.templateIds
      });
    });
  },
  jump: function jump() {
    var that = this;
    var business_id = app.globalData.userInfo.uid;
    app.applySubMsg(this.data.templateIds, business_id, function () {
      wx.navigateTo({
        url: "../tarotSignIn/index"
      });
    });
  },
  handleInvite: function handleInvite() {
    wx.navigateTo({
      url: "../../pages/limitInvite/index"
    });
  },
  fetchCouponTip: function fetchCouponTip() {
    var that = this;
    api.fetchGet(api.baseUrl + "entrance/productentrance?alias=mini_task_coupon", {}).then(function (res) {
      var tabs = res.tabs;
      tabs.forEach(function (v, k) {
        tabs[k].cate_id = "mini_task_coupon";
        that.setData({
          couponTip: tabs[k].content
        });
      });
    });
  }
});