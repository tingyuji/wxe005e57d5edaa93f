var api = require('./../../utils/api.js');var app = getApp();var innerAudioContext;Page({
  data: {
    windowWidth: 0,
    windowHeight: 0,
    showPage: false,
    hasAudio: false,
    commentsData: {},
    currentText: '点击重听',
    scoreArr: [{
      choose: 0
    }, {
      choose: 0
    }, {
      choose: 0
    }, {
      choose: 0
    }, {
      choose: 0
    }],
    score: 0,
    // 用于筛选
    keywordsData: [],
    // 用于页面展示
    keywords: [],
    idArr: []
  },
  onLoad: function onLoad(options) {},
  onShow: function onShow(options) {
    var commentsData = wx.getStorageSync('commentsData');
    innerAudioContext = wx.createInnerAudioContext();
    this.setData({
      commentsData: commentsData
    });
    this.fetchData();
  },
  onHide: function onHide() {},
  onUnload: function onUnload() {
    innerAudioContext.stop();
    innerAudioContext.destroy();
  },
  fetchData: function fetchData(postId) {
    var that = this;
    wx.showToast({
      title: '加载中...',
      icon: 'loading',
      duration: 10000
    });
    api.fetchGet(api.baseUrl + 'ask/marking/keywords').then(function (res) {
      wx.hideToast();
      var keywords = res.keywords;
      keywords.forEach(function (v, k) {
        v.active = 0;
      });
      that.setData({
        keywords: keywords,
        keywordsData: keywords,
        showPage: true
      });
    });
  },
  playAudio: function playAudio(e) {
    var that = this;
    var audioSrc;
    var hasAudio = that.data.hasAudio;
    var commentsData = that.data.commentsData;
    var commentId = e.currentTarget.dataset.commentid;
    if (hasAudio) {
      if (commentsData.play) {
        innerAudioContext.pause();
        commentsData.play = false;
        that.setData({
          currentText: '已暂停',
          commentsData: commentsData
        });
      } else {
        innerAudioContext.play();
        commentsData.play = true;
        that.setData({
          currentText: '正在播放',
          commentsData: commentsData
        });
      }
    } else {
      that.setData({
        currentText: '正在缓存'
      });
      api.fetchGet(api.baseUrl + 'forum/posts/' + commentId + '/audio', {
        noTip: true
      }).then(function (res) {
        audioSrc = res.date.resource_url;
        innerAudioContext.src = audioSrc;
        innerAudioContext.obeyMuteSwitch = false;
        innerAudioContext.autoplay = true;
        innerAudioContext.onPlay(function () {
          commentsData.play = true;
          that.setData({
            hasAudio: true,
            currentText: '正在播放',
            commentsData: commentsData
          });
        });
        innerAudioContext.onEnded(function () {
          commentsData.play = false;
          that.setData({
            hasAudio: false,
            currentText: '点击重听',
            commentsData: commentsData
          });
        });
      });
    }
  },
  scoreFn: function scoreFn(e) {
    var that = this;
    var index = e.currentTarget.dataset.index;
    var score = index + 1;
    var scoreArr = that.data.scoreArr;
    var keywordsData = that.data.keywordsData;
    var newKeywords = [];
    scoreArr.forEach(function (v, k) {
      v.choose = 0;
    });
    scoreArr.forEach(function (v, k) {
      if (k <= index) {
        v.choose = 1;
      }
    });
    keywordsData.forEach(function (v, k) {
      v.active = 0;
      if (score < 3 && v.effect == 2) {
        newKeywords.push(v);
      } else if (score == 3 && v.effect == 3) {
        newKeywords.push(v);
      } else if (score > 3 && v.effect == 1) {
        newKeywords.push(v);
      }
    });
    that.setData({
      scoreArr: scoreArr,
      score: score,
      keywords: newKeywords,
      idArr: []
    });
  },
  chooseLbleFn: function chooseLbleFn(e) {
    var that = this;
    var id = e.currentTarget.dataset.id;
    var index = e.currentTarget.dataset.index;
    var keywords = that.data.keywords;
    var idArr = that.data.idArr;
    keywords.forEach(function (v, k) {
      if (index == k) {
        if (v.active) {
          v.active = 0;
          idArr.forEach(function (val, key) {
            if (val == v.id) {
              idArr.splice(key, 1);
            }
          });
        } else {
          if (idArr.length > 2) {
            wx.showToast({
              title: '最多可选3条',
              icon: 'none',
              duration: 800
            });
            return;
          }
          v.active = 1;
          idArr.push(v.id);
        }
      }
    });
    that.setData({
      keywords: keywords,
      idArr: idArr
    });
  },
  submit: function submit() {
    var that = this;
    var commentId = that.data.commentsData.comment_id;
    var idArr = that.data.idArr;
    var star = that.data.score;
    var keywords;
    idArr.forEach(function (v, k) {
      if (k == 0) {
        keywords = v;
      } else {
        keywords = keywords + '-' + v;
      }
    });
    wx.showToast({
      title: '提交中...',
      icon: 'loading',
      duration: 10000
    });
    api.fetchPost(api.baseUrl + 'ask/marking/' + commentId, {
      star: star,
      keywords: keywords
    }).then(function (res) {
      wx.hideToast();
      wx.navigateBack({
        delta: 1
      });
    });
  }
});