var api = require("./../../utils/api.js");var app = getApp();Page({
  /**
   * 页面的初始数据
   */
  data: {
    rankList: [],
    //排行榜
    ownRank: [],
    //自己的排名
    rankTop: [{}, {}, {}],
    //前三排行榜
    scrollHeight: "",
    hasLogin: false,
    page: 2,
    isMore: true
  },
  //获取排行榜
  getRankingList: function getRankingList() {
    var that = this;
    api.fetchGet(api.baseUrl + "ask/invite/week_top_list", {
      limit: 20,
      page: 0
    }).then(function (res) {
      var items = res.items.items.slice(0, 3);
      var list = res.items.items.splice(0, 3);
      that.setData({
        rankList: res.items.items,
        ownRank: res.items.own[0],
        //未登录时,own为空，不展示自己的排名，登录后，展示自己的排名
        rankTop: items
      });
    });
  },
  handleFresh: function handleFresh() {
    var _this = this;
    var that = this;
    var isMore = that.data.isMore;
    var page = that.data.page;
    if (!isMore) {
      return;
    }
    wx.showToast({
      title: "加载中...",
      icon: "loading",
      duration: 1500
    });
    api.fetchGet(api.baseUrl + "ask/invite/week_top_list", {
      limit: 10,
      page: page
    }).then(function (res) {
      var items = res.items.items;
      if (JSON.stringify(res) == "{}") {
        return _this.setData({
          isMore: false
        });
      }
      if (items.length < 10) {
        isMore = false;
      } else {
        page += 1;
      }
      var list = that.data.rankList.concat(items);
      that.setData({
        isMore: isMore,
        page: page,
        rankList: list
      });
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    this.getRankingList();
    var res = wx.getSystemInfoSync();
    this.setData({
      scrollHeight: res.windowHeight - (450 + 128) / 2
    });
    console.log("scrollHeight", this.data.scrollHeight);
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {
    var userInfo = app.globalData.userInfo;
    if (userInfo != null && "tok" in userInfo) {
      this.setData({
        hasLogin: true
      });
    } else {
      this.setData({
        hasLogin: false
      });
    }
    console.log(this.data.hasLogin);
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});