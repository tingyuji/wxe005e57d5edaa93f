var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var api = require("./../../utils/api.js");var config = require("../../config.js");var app = getApp();var timer, timerEvaluate;Page({
  data: {
    windowHeight: 0,
    windowWidth: 0,
    couponNum: "empty",
    userInfo: {},
    askQuestionsList: [],
    consultingNum: 0,
    showPrompt: false,
    guideFlag: false,
    promptAnim: "",
    // 展示霸屏切片
    showTip: false,
    showConsumePrompt: false,
    downloadPromptText: "下载“问问塔罗”APP即可体验与占卜师连麦进行占卜服务(回复“下载”即可获得5分钟免费连麦时长)",
    platform: "",
    msgImage: "https://static.shengri.cn/uploads/QA_mp/tarot_banner.jpeg?imageslim",
    // 公告
    notice_list: [],
    showTimeLine: false,
    // 小程序跳转参数
    redirectConfig: {},
    // 订阅消息模板
    templateIds: [],
    aid: "",
    bannerAlias: "tarot_mini_banner",
    evaluateList: [],
    //评价列表
    topChatRecommend: [],
    //优秀达人推荐
    hasShow: false,
    //是否展示悬浮框
    balance: 0,
    //钱包余额
    hasWallet: false,
    //是否展示钱包==》是否登录
    searchValue: "",
    liverList: [],
    uid: ''
  },
  //点击抽牌，
  handleCards: function handleCards() {
    wx.navigateTo({
      url: "../tarotGame/index"
    });
  },
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: "新用户会有一张免费提问券（可以问感情、事业等问题）",
      path: "/pages/index/index",
      imageUrl: "https://static.shengri.cn/uploads/QA_mp/InvitedShare@2x-1.png?imageslim"
    };
  },
  onShareTimeline: function onShareTimeline() {
    return {
      title: "新用户会有一张免费提问券（可以问感情、事业等问题）"
    };
  },
  onLoad: function onLoad(options) {
    var _this = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
      var that, scene, params, redirectConfigArr;
      return _regeneratorRuntime2().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            that = _this; //console.log('options----' + JSON.stringify(options))
            if (options && "aid" in options) {
              _this.setData({
                aid: options.aid
              });
            }
            if (options && "chn" in options) {
              api.setChannel(options.chn);
            } else if (options.scene) {
              //console.log('options.scene------' + options.scene);
              scene = options.scene; // 快应用分享小程序二维码 scene包含 渠道号+邀请人id
              if (scene.indexOf("iuid") > -1) {
                params = scene.split("iuid");
                api.setChannel(params[0]);
                wx.setStorageSync("sessionSource", true);
                wx.setStorageSync("inviteUserId", params[1]);
                wx.navigateTo({
                  url: "../tarotGame/index?inviteUserId=" + params[1]
                });
              } else {
                api.setChannel(options.scene);
              }
            } else if (options.postId) {
              wx.navigateTo({
                url: "../detail/index?postId=" + options.postId
              });
            } else if (options.inviteUserId) {
              wx.setStorageSync("sessionSource", true);
              wx.setStorageSync("inviteUserId", options.inviteUserId);
              wx.navigateTo({
                url: "../tarotGame/index?inviteUserId=" + options.inviteUserId
              });
            } else if (options.redirect) {
              wx.navigateTo({
                url: decodeURIComponent(options.redirect)
              });
            }
            // that.serQr()
            that.fetchData();
            that.fetchNotice();
            that.shareData();
            that.fetchTemplateIds();
            that.getTopChatRecommend();
            _context.next = 10;
            return app.fetchRedirectConfig({
              position: "index"
            });
          case 10:
            redirectConfigArr = _context.sent;
            if (redirectConfigArr.length > 0) {
              _this.setData({
                redirectConfig: redirectConfigArr[0]
              });
            }
          case 12:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }))();
  },
  onShow: function onShow() {
    var _this2 = this;
    var that = this;
    that.getEvaluate();
    var showPrompt = false;
    wx.showShareMenu({
      menus: ["shareAppMessage", "shareTimeline"]
    });
    wx.setNavigationBarTitle({
      title: config.name
    });
    var nonage = wx.getStorageSync("nonage");
    if (nonage === 1) {
      return wx.redirectTo({
        url: "../identity/index"
      });
    }
    if (nonage === -1) {
      return wx.navigateTo({
        url: "../identity/index"
      });
    }
    wx.getSystemInfo({
      success: function success(res) {
        _this2.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth,
          platform: res.platform
        });
      }
    });
    if (wx.getStorageSync("indexPopup")) {
      showPrompt = true;
    }
    if (app.globalData.wxInfo) {
      that.setData({
        userInfo: app.globalData.wxInfo,
        consultingNum: that.randomNum(3000, 5500),
        showPrompt: showPrompt
      });
      if (app.globalData.userInfo) {
        that.setData({
          hasWallet: true,
          uid: app.globalData.userInfo.uid
        });
        that.fetchCouponNum();
        that.fetchWallet();
        that.getAskLiver();
      }
    } else {
      that.setData({
        userInfo: {
          avatarUrl: "https://static.shengri.cn/uploads/xydd/m/avatar@3x.png?imageslim",
          nickName: "未登录"
        },
        consultingNum: that.randomNum(3000, 5500)
      });
    }
    //  引导 app 是否展示
    var day = wx.getStorageSync("day") || "";
    var date = new Date();
    var nowDay = date.getDate();
    var nowHour = date.getHours();
    if (day !== nowDay && nowHour >= 20 && nowHour < 24) {
      this.setData({
        showTip: true
      });
    }
  },
  onHide: function onHide() {
    clearInterval(timer);
  },
  onUnload: function onUnload() {
    clearInterval(timer);
  },
  noClose: function noClose() {
    return;
  },
  closeFn: function closeFn() {
    this.setData({
      showPrompt: false
    });
    wx.removeStorageSync("indexPopup");
  },
  shareData: function shareData() {
    var that = this;
    var url = api.baseUrl + "store/weapp/share";
    api.fetchGet(url, {
      noTip: true
    }).then(function (res) {
      that.setData({
        showTimeLine: res.showTimeLine
      });
    });
  },
  serQr: function serQr() {
    var that = this;
    var url = api.baseUrl + "code/wxa";
    api.fetchPost(url, {
      type: "B",
      params: {
        scene: "1250iuid2881461"
      }
    }).then(function (res) {
      //console.log(res)
    });
  },
  fetchData: function fetchData() {
    var that = this;
    api.fetchGet(api.baseUrl + "ask/question/lists", {}).then(function (res) {
      var data = res.items;
      data.forEach(function (v, k) {
        v.hidden = false;
      });
      that.setData({
        askQuestionsList: data
      });
      // if (!wx.getStorageSync("ShowGuide")) {
      //   setTimeout(() => {
      //     that.setData({
      //       guideFlag: true,
      //     });
      //     setTimeout(() => {
      //       that.setData({
      //         promptAnim: "promptBgAnim1",
      //       });
      //     }, 400);
      //   }, 2000);
      // }
    });
  },
  fetchCouponNum: function fetchCouponNum() {
    var that = this;
    api.fetchGet(api.baseUrl + "ask/invite/lists", {}).then(function (res) {
      that.setData({
        couponNum: res.count
      });
    });
  },
  fetchNotice: function fetchNotice() {
    var that = this;
    api.fetchGet(api.baseUrl + "entrance/productentrance?alias=tarotonline_notice", {}).then(function (res) {
      that.setData({
        notice_list: res.tabs
      });
    });
  },
  randomNum: function randomNum(minNum, maxNum) {
    switch (arguments.length) {
      case 1:
        return parseInt(Math.random() * minNum + 1, 10);
        break;
      case 2:
        return parseInt(Math.random() * (maxNum - minNum + 1) + minNum, 10);
        break;
      default:
        return 0;
        break;
    }
  },
  navToDiceGame: function navToDiceGame() {
    wx.navigateTo({
      url: "../diceGame/index"
    });
    // if (app.checkLoginStatus()) {
    //
    // }
  },
  jump: function jump(e) {
    var redirectConfig = this.data.redirectConfig;
    var path = e.currentTarget.dataset.path;
    var url;
    if (path == 1) {
      url = "../tarotSignIn/index";
    } else if (path == 2) {
      url = "../tarotInstructions/index";
    } else if (path == 3) {
      url = "../myQuestion/index";
    } else if (path == 4) {
      url = "../couponRedemption/index";
    } else if (path == 5) {
      url = "../diceGame/index";
    }
    if (path == 7) {
      url = "../advisory/index";
    } else if (path == 6) {
      return wx.navigateToMiniProgram({
        appId: redirectConfig.wxAppId,
        path: redirectConfig.path ? redirectConfig.path : "pages/index/index",
        extraData: {},
        envVersion: "trial",
        success: function success(res) {}
      });
    }
    wx.navigateTo({
      url: url
    });
    // 跳转之后再修改状态
    var receive = this.data.receive;
    if (receive) {
      this.setData({
        showPrompt: false
      });
    } else {
      this.setData({
        showPrompt: false
      });
    }
  },
  showQuestionsList: function showQuestionsList(e) {
    var askQuestionsList = this.data.askQuestionsList;
    var index = e.currentTarget.dataset.index;
    askQuestionsList.forEach(function (v, k) {
      if (index == k) {
        v.hidden = !v.hidden;
      } else {
        v.hidden = true;
      }
    });
    this.setData({
      askQuestionsList: askQuestionsList
    });
  },
  login: function login() {
    var that = this;
    // 没登录去登陆
    var isLogin = app.isLogin();
    // 如果没有登录，就去登录授权
    if (!isLogin) {
      if (app.getAllow()) {
        wx.navigateTo({
          url: "../login/login"
        });
      } else {
        wx.navigateTo({
          url: "../authorization/authorization"
        });
      }
      return;
    }
  },
  submitFormid2: function submitFormid2(e) {
    var askQuestionsList = this.data.askQuestionsList;
    var questionslistindex = e.currentTarget.dataset.questionslistindex;
    var questionsindex = e.currentTarget.dataset.questionsindex;
    var that = this;
    // 消息推送埋点
    var formId = e.detail.formId;
    if (app.globalData.wxInfo) {
      var openId = app.globalData.wxInfo.openId;
      var url;
      //console.log('---------------');
      //console.log(formId);
      api.fetchPost(api.baseUrl + "wechat/saveformdata", {
        open_id: openId,
        form_id: formId,
        context: {
          type: 1
        },
        noTip: true
      }).then(function (res) {});
    }
    wx.navigateTo({
      url: "../tarotGame/index?questionText=" + askQuestionsList[questionslistindex].questions[questionsindex].content
    });
  },
  guideFn: function guideFn() {
    wx.setStorageSync("ShowGuide", true);
    this.setData({
      guideFlag: false
    });
  },
  showConsumePromptFn: function showConsumePromptFn() {
    var that = this;
    var platform = this.data.platform;
    this.setData({
      showConsumePrompt: true,
      showTip: false,
      downloadPromptText: platform == "ios" ? "下载“问问塔罗-塔罗牌占卜爱情星座运势”APP即可体验与占卜师连麦进行占卜服务(回复“下载”即可获得5分钟免费连麦时长)" : "下载“问问塔罗”APP即可体验与占卜师连麦进行占卜服务(回复“下载”即可获得5分钟免费连麦时长)"
    });
    wx.setStorageSync("day", new Date().getDate());
  },
  hiddenTip: function hiddenTip() {
    this.setData({
      showTip: false
    });
    wx.setStorageSync("day", new Date().getDate());
  },
  cancel: function cancel() {
    this.setData({
      showConsumePrompt: false
    });
  },
  fetchTemplateIds: function fetchTemplateIds() {
    var that = this;
    api.fetchGet(api.baseUrl + "wxapp/templateIds", {
      business: "invite_credit_notification"
    }).then(function (res) {
      that.setData({
        templateIds: res.templateIds
      });
    });
  },
  // 跳转获取提问券
  navToCoupon: function navToCoupon() {
    var _this3 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
      return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            app.applySubMsg(_this3.data.templateIds, app.globalData.userInfo.uid, function () {
              return wx.navigateTo({
                url: "../couponRedemption/index"
              });
            });
          case 1:
          case "end":
            return _context2.stop();
        }
      }, _callee2);
    }))();
  },
  //获取评价
  getEvaluate: function getEvaluate() {
    var that = this;
    api.fetchGet(api.baseUrl + "ask/chat/user/marks", {
      limit: 20
    }).then(function (res) {
      if (timerEvaluate) {
        clearInterval(timerEvaluate);
      }
      if (res.items.length == 0) {
        return timerEvaluate = setInterval(function () {
          that.getEvaluate();
        }, 1000);
      }
      var items = res.items.slice(0, 5);
      that.setData({
        evaluateList: items
      });
      var i = 14;
      timer = setInterval(function () {
        var newArr = [];
        for (var _i = 0; _i < 5; _i++) {
          var item = res.items[Math.floor(Math.random() * res.items.length)];
          newArr.push(item);
        }
        that.setData({
          evaluateList: newArr
        });
      }, 5000);
    });
  },
  //优秀达人推荐
  getTopChatRecommend: function getTopChatRecommend() {
    var that = this;
    api.fetchGet(api.baseUrl + "s/chat/smallapp/recommends").then(function (res) {
      that.setData({
        topChatRecommend: res.items
      });
    });
  },
  getAskLiver: function getAskLiver() {
    var that = this;
    api.fetchGet(api.baseUrl + "ask/live/list", {
      // page: 0,
      // limit: 3,
    }).then(function (res) {
      that.setData({
        liverList: res.items
      });
    });
  },
  handleToLiver: function handleToLiver(e) {
    if (app.checkLoginStatus()) {
      var uid = e.currentTarget.dataset.uid;
      wx.navigateTo({
        url: "../chatInfo/index?uid=" + uid
      });
    }
  },
  //跳转到达人直播间
  handleChatLive: function handleChatLive(e) {
    if (app.checkLoginStatus()) {
      var _e$currentTarget$data = e.currentTarget.dataset,
        channel = _e$currentTarget$data.channel,
        uid = _e$currentTarget$data.uid,
        keyword = _e$currentTarget$data.keyword;
      wx.navigateTo({
        url: "../rtmIndex/index?uid=".concat(uid, "&channel=").concat(channel, "&keyword=").concat(keyword)
      });
    }
  },
  handleChatInfo: function handleChatInfo(e) {
    if (app.checkLoginStatus()) {
      var uid = e.currentTarget.dataset.uid;
      wx.navigateTo({
        url: "../chatInfo/index?uid=".concat(uid)
      });
    }
  },
  //查看更多优秀达人推荐
  handleMore: function handleMore() {
    if (app.checkLoginStatus()) {
      wx.navigateTo({
        url: "../chatRecommend/index"
      });
    }
  },
  handleToDownLoad: function handleToDownLoad() {
    wx.navigateTo({
      url: "../leadDownload/index"
    });
  },
  handleSeeReward: function handleSeeReward() {
    this.reward.open();
  },
  handleShow: function handleShow(e) {
    this.setData({
      hasShow: e.detail
    });
  },
  // 获取钱包余额
  fetchWallet: function fetchWallet() {
    var that = this;
    api.fetchGet(api.baseUrl + "store/wallet").then(function (res) {
      that.setData({
        balance: res.userBalance
      });
    });
  },
  handleSearch: function handleSearch() {
    wx.navigateTo({
      url: this.data.searchValue
    });
  },
  //获取昵称
  getValue: function getValue(e) {
    this.setData({
      searchValue: e.detail.value
    });
  },
  handleLiveMore: function handleLiveMore() {
    wx.navigateTo({
      url: '../liveList/index'
    });
  },
  privateAgree: function privateAgree() {
    var that = this;
    if (!wx.getStorageSync("ShowGuide")) {
      setTimeout(function () {
        that.setData({
          guideFlag: true
        });
        setTimeout(function () {
          that.setData({
            promptAnim: "promptBgAnim1"
          });
        }, 400);
      }, 2000);
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {
    var that = this;
    that.reward = that.selectComponent("#reward");
  }
});