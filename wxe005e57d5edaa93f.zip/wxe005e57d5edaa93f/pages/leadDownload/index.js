Page({
  /**
   * 页面的初始数据
   */
  data: {
    statusBarHeight: 0,
    //状态栏的高度
    navHeight: 0
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    //获取胶囊与顶部的距离
    var menuButton = wx.getMenuButtonBoundingClientRect();
    var res = wx.getSystemInfoSync();
    //状态栏的高度
    var statusBarHeight = res.statusBarHeight;
    //胶囊距离页面顶部的距离
    var top = menuButton.top;
    //除状态栏的navHeight
    var navHeight = menuButton.height + (top - statusBarHeight) * 2;
    console.log(statusBarHeight, navHeight);
    this.setData({
      statusBarHeight: statusBarHeight,
      navHeight: navHeight
    });
  },
  handlCopy: function handlCopy() {
    wx.setClipboardData({
      data: "http://6ds.me/pCZ5R",
      success: function success(result) {
        // wx.getClipboardData({
        //   success(res) {},
        // });
      }
    });
  },
  handleReturn: function handleReturn() {
    wx.navigateBack();
  }
});