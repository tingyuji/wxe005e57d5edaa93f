var api = require("./../../utils/api.js");var app = getApp();Page({
  data: {
    windowWidth: 0,
    windowHeight: 0,
    showTimeLine: false
  },
  onLoad: function onLoad(options) {
    this.shareData();
  },
  onShow: function onShow() {
    var _this = this;
    wx.getSystemInfo({
      success: function success(res) {
        _this.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        });
      }
    });
    this.setData({
      page: 0
    });
  },
  onReady: function onReady() {
    this.appPopup = this.selectComponent("#appShadow");
  },
  onHide: function onHide() {},
  onUnload: function onUnload() {},
  onReachBottom: function onReachBottom() {},
  shareData: function shareData() {
    var that = this;
    var url = api.baseUrl + "store/weapp/share";
    api.fetchGet(url, {
      noTip: true
    }).then(function (res) {
      that.setData({
        showTimeLine: res.showTimeLine
      });
    });
  },
  promptDownload: function promptDownload() {
    // if (this.data.showTimeLine) {
    //   this.appPopup.showPopup();
    // }
    wx.navigateTo({
      url: "../leadDownload/index"
    });
  },
  statisticalClickDown: function statisticalClickDown() {
    console.log("------");
    // 没用作用，只是为了统计点击下载量
  }
});