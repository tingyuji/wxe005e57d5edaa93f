var _toConsumableArray2 = require("../../@babel/runtime/helpers/toConsumableArray");var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var api = require("./../../utils/api.js");var app = getApp();var innerAudioContext;var isLoading = false;Page({
  /**
   * 页面的初始数据
   */
  data: {
    bannerList: [],
    current: 0,
    //banner
    currentTab: 0,
    //标题
    typeTitle: [],
    windowHeight: "",
    dataList: [],
    clickIndex: "",
    //播放音频用于传递
    currentIndex: -1 //播放音频用于判断
  },
  //轮播图切换
  handleBindChange: function handleBindChange(e) {
    var _e$detail = e.detail,
      current = _e$detail.current,
      source = _e$detail.source;
    if (source === "autoplay" || source === "touch") {
      this.setData({
        current: current
      });
    }
  },
  //切换标题
  handleTitle: function handleTitle(e) {
    var current = e.currentTarget.dataset.current;
    var dataList = this.data.dataList;
    var currentTab = this.data.currentTab;
    if (current === currentTab) return;
    // console.log("dataList[current]", dataList[current]);
    var currentList = dataList[current].items;
    this.setData({
      currentTab: current
    });
    if (currentList.length <= 0) {
      this.handleFresh();
    }
  },
  catchTouchMove: function catchTouchMove(res) {
    return false;
  },
  //获取推荐/人气/新人的type值
  getChatType: function getChatType() {
    var _this = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
      var that, _yield$api$fetchGet, items, data;
      return _regeneratorRuntime2().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            that = _this;
            _context.prev = 1;
            _context.next = 4;
            return api.fetchGet(api.baseUrl + "ask/chat/filters");
          case 4:
            _yield$api$fetchGet = _context.sent;
            items = _yield$api$fetchGet.items;
            //初始化datalist
            data = items.map(function (v, k) {
              return {
                items: [],
                page: 0,
                isMore: true,
                type: v.type
              };
            });
            that.setData({
              typeTitle: items,
              dataList: data
            });
            that.handleFresh();
            _context.next = 13;
            break;
          case 11:
            _context.prev = 11;
            _context.t0 = _context["catch"](1);
          case 13:
          case "end":
            return _context.stop();
        }
      }, _callee, null, [[1, 11]]);
    }))();
  },
  //下拉刷新
  handleFresh: function handleFresh() {
    var _this2 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
      var that, currentIndex, dataList, oldData, newData;
      return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            that = _this2; //当前索引
            currentIndex = _this2.data.currentTab;
            dataList = _this2.data.dataList; //获取当前索引对应的对象
            oldData = dataList[currentIndex]; //没有更多加载数据时，中断请求
            if (oldData.isMore) {
              _context2.next = 6;
              break;
            }
            return _context2.abrupt("return");
          case 6:
            if (!isLoading) {
              _context2.next = 8;
              break;
            }
            return _context2.abrupt("return");
          case 8:
            _context2.next = 10;
            return that.fetchMore(oldData);
          case 10:
            newData = _context2.sent;
            // console.log(newData);
            dataList[currentIndex] = newData;
            _this2.setData({
              dataList: dataList
            });
          case 13:
          case "end":
            return _context2.stop();
        }
      }, _callee2);
    }))();
  },
  //加载更多
  fetchMore: function fetchMore(params) {
    var _this3 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3() {
      var that, _JSON$parse, type, items, page, isMore, res, v;
      return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
        while (1) switch (_context3.prev = _context3.next) {
          case 0:
            that = _this3; //实现对象深拷贝
            _JSON$parse = JSON.parse(JSON.stringify(params)), type = _JSON$parse.type, items = _JSON$parse.items, page = _JSON$parse.page, isMore = _JSON$parse.isMore;
            isLoading = true;
            _context3.prev = 3;
            _context3.next = 6;
            return api.fetchGet(api.baseUrl + "ask/chat/recommend_list", {
              type: type,
              page: page
            });
          case 6:
            res = _context3.sent;
            v = res.items.length < 10;
            items = page === 0 ? res.items : [].concat(_toConsumableArray2(items), _toConsumableArray2(res.items));
            // console.log("fetch items", items);
            if (v) {
              isMore = false;
            } else {
              page = page + 1;
            }
            return _context3.abrupt("return", {
              type: type,
              items: items,
              page: page,
              isMore: isMore
            });
          case 13:
            _context3.prev = 13;
            _context3.t0 = _context3["catch"](3);
          case 15:
            _context3.prev = 15;
            isLoading = false;
            return _context3.finish(15);
          case 18:
          case "end":
            return _context3.stop();
        }
      }, _callee3, null, [[3, 13, 15, 18]]);
    }))();
  },
  // 点击播放语音
  playAudio: function playAudio(e) {
    var that = this;
    var currentTab = that.data.currentTab;
    var index = e.currentTarget.dataset.index;
    var currentIndex = that.data.currentIndex;
    var list = that.data.dataList;
    var audio = list[currentTab].items[index].audio.audio_url;
    var itemsData = list[currentTab].items;
    if (currentIndex === index) {
      if (itemsData[index].isPlay) {
        itemsData[index].isPlay = false;
        innerAudioContext.stop();
      } else {
        itemsData[index].isPlay = true;
        innerAudioContext.play();
      }
      this.setData({
        dataList: list
      });
    } else {
      itemsData.forEach(function (v, k) {
        itemsData[k].isPlay = false;
      });
      innerAudioContext.src = audio;
      console.log("audio-----", audio);
      innerAudioContext.play();
      that.setData({
        dataList: list,
        currentIndex: index
      });
    }
    that.setData({
      clickIndex: index
    });
  },
  audioOnPlay: function audioOnPlay() {
    var clickIndex = this.data.clickIndex;
    var currentTab = this.data.currentTab;
    var list = this.data.dataList;
    var itemsData = list[currentTab].items;
    itemsData[clickIndex].isPlay = true;
    this.setData({
      dataList: list
    });
  },
  audioOnEnded: function audioOnEnded() {
    var clickIndex = this.data.clickIndex;
    var currentTab = this.data.currentTab;
    var list = this.data.dataList;
    var itemsData = list[currentTab].items;
    itemsData[clickIndex].isPlay = false;
    this.setData({
      dataList: list
    });
  },
  //获取配置的banner
  getBanner: function getBanner() {
    var that = this;
    api.fetchGet(api.baseUrl + "entrance/productentrance?alias=mini_expert_banner", {}).then(function (res) {
      that.setData({
        bannerList: res.tabs
      });
    });
  },
  //跳转到达人详情
  handleChatInfo: function handleChatInfo(e) {
    if (app.checkLoginStatus()) {
      var uid = e.currentTarget.dataset.uid;
      wx.navigateTo({
        url: "../chatInfo/index?uid=" + uid
      });
    }
  },
  //跳转到复制链接页
  handleToDownLoad: function handleToDownLoad() {
    wx.navigateTo({
      url: "../leadDownload/index"
    });
  },
  //推荐/人气/新人切换
  swiperChange: function swiperChange(e) {
    this.setData({
      currentTab: e.detail.current
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    var _this4 = this;
    //获取高度
    var res = wx.getSystemInfoSync();
    this.setData({
      windowHeight: res.windowHeight - 204
    });
    this.getBanner();
    //播放语音
    innerAudioContext = wx.createInnerAudioContext();
    console.log("innerAudioContext-->", innerAudioContext);
    innerAudioContext.onPlay(function () {
      _this4.audioOnPlay();
    });
    innerAudioContext.onEnded(function () {
      _this4.audioOnEnded();
    });
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {
    this.getChatType();
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {
    innerAudioContext.stop();
    //innerAudioContext.destroy();
    // innerAudioContext = null;
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {
    //innerAudioContext.stop();
    innerAudioContext.destroy();
    // innerAudioContext = null;
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});