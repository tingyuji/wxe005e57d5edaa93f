var config = require("../../config.js");var api = require("../../utils/api.js");var app = getApp();var timer;Page({
  data: {
    name: config.name,
    logo: config.logo,
    wxInfo: {
      avatarUrl: "",
      nickName: ""
    },
    showFunc: false
  },
  onShow: function onShow() {
    this.checkAuthStatus();
  },
  onLoad: function onLoad(options) {
    this.setData(options);
    wx.login({
      success: function success(res) {
        console.log("res", res);
        wx.setStorageSync("loginCode", res.code);
      }
    });
  },
  onHide: function onHide() {
    clearTimeout(timer);
  },
  onUnload: function onUnload() {
    clearTimeout(timer);
    wx.removeStorageSync("loginCode");
  },
  checkShowFunc: function checkShowFunc() {
    var showFunc = this.data.showFunc;
    this.setData({
      showFunc: !showFunc
    });
  },
  checkAuthStatus: function checkAuthStatus() {
    var wxInfo = wx.getStorageSync("wxInfo") || {};
    if ("avatarUrl" in wxInfo && wxInfo.avatarUrl != "") {
      this.setData({
        wxInfo: {
          avatarUrl: wxInfo.avatarUrl,
          nickName: wxInfo.nickName
        }
      });
    }
  },
  getPhoneNumber: function getPhoneNumber(e) {
    var that = this;
    var detail = e.detail;
    if (detail.errMsg === "getPhoneNumber:fail user deny") {
      return wx.showToast({
        title: "用户拒绝授权",
        icon: "none",
        duration: 2000
      });
    }
    var data = {
      iv: detail.iv,
      encryptedData: detail.encryptedData
    };
    wx.checkSession({
      success: function success() {
        var userInfo = wx.getStorageSync("wxInfo");
        if ("unionId" in userInfo) {
          data.typeId = 66;
          data.udid = userInfo.unionId;
        } else {
          data.typeId = 72;
          data.udid = userInfo.openId;
        }
        that.bindPhone(data);
      },
      fail: function fail() {
        app.getUserInfo(function (userInfo) {
          if ("unionId" in userInfo) {
            data.typeId = 66;
            data.udid = userInfo.unionId;
          } else {
            data.typeId = 72;
            data.udid = userInfo.openId;
          }
          that.bindPhone(data);
        });
      }
    });
    return;
  },
  bindPhone: function bindPhone(data) {
    var that = this;
    var apiUrl = api.baseUrl + "account/mina_ease_login";
    wx.showToast({
      title: "加载中...",
      icon: "loading",
      duration: 5000
    });
    api.fetchPost(apiUrl, data).then(function (resp) {
      wx.hideToast();
      app.setUserInfo(resp);
      api.setToken(resp.tok);
      if (resp.is_register) {
        wx.setStorageSync("indexPopup", true);
      }
      if (resp.is_register && wx.getStorageSync("sessionSource")) {
        that.sessionRegistration();
      }
      that.checkNonage(resp);
    }).catch(function (error) {
      wx.hideToast();
    });
  },
  checkNonage: function checkNonage(resp) {
    if (resp.nonage == -1) {
      if (resp.birth_y == 0) {
        wx.setStorageSync("nonage", -1);
        wx.redirectTo({
          url: "../identity/index"
        });
      } else {
        wx.setStorageSync("nonage", 0);
        wx.navigateBack({
          delta: 1
        });
      }
    }
    if (resp.nonage == 0) {
      wx.setStorageSync("nonage", 0);
      wx.navigateBack({
        delta: 1
      });
    }
    if (resp.nonage == 1) {
      wx.setStorageSync("nonage", 1);
      wx.redirectTo({
        url: "../identity/index"
      });
    }
  },
  sessionRegistration: function sessionRegistration() {
    var inviteUserId = wx.getStorageSync("inviteUserId");
    var apiUrl = api.baseUrl + "ask/invite/free_coupon";
    api.fetchPost(apiUrl, {
      invite_user_id: inviteUserId,
      noTip: true
    }).then(function (resp) {
      wx.removeStorageSync("inviteUserId");
    }).catch(function (error) {});
  },
  navBack: function navBack() {
    return wx.navigateBack();
  }
});