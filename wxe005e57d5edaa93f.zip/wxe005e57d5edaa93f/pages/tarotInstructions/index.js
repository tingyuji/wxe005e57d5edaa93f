var api = require('./../../utils/api.js');var app = getApp();Page({
  data: {
    windowWidth: 0,
    windowHeight: 0,
    hiddenLable1: true,
    hiddenLable2: true,
    hiddenLable3: true,
    hiddenLable4: true
  },
  onLoad: function onLoad(options) {},
  onShow: function onShow() {
    var _this = this;
    wx.getSystemInfo({
      success: function success(res) {
        _this.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        });
      }
    });
  },
  showLable: function showLable(e) {
    var path = e.currentTarget.dataset.path;
    if (path == 1) {
      this.setData({
        hiddenLable1: !this.data.hiddenLable1
      });
    } else if (path == 2) {
      this.setData({
        hiddenLable2: !this.data.hiddenLable2
      });
    } else if (path == 3) {
      this.setData({
        hiddenLable3: !this.data.hiddenLable3
      });
    } else if (path == 4) {
      this.setData({
        hiddenLable4: !this.data.hiddenLable4
      });
    }
  }
});