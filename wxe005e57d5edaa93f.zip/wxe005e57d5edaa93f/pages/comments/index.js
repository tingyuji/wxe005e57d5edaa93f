var api = require("./../../utils/api.js");Page({
  /**
   * 页面的初始数据
   */
  data: {
    userMark: [],
    windowHeight: "",
    isMore: true,
    page: 1,
    uid: ""
  },
  // 达人评价列表
  getChatEvaluateList: function getChatEvaluateList() {
    var that = this;
    api.fetchGet(api.baseUrl + "ask/chat/user/marks", {
      user_id: that.data.uid,
      page: 0,
      limit: 10
    }).then(function (res) {
      that.setData({
        userMark: res.items
      });
    });
  },
  handleFresh: function handleFresh() {
    var that = this;
    var isMore = that.data.isMore;
    var page = that.data.page;
    if (!isMore) {
      return;
    }
    wx.showToast({
      title: "加载中...",
      icon: "loading",
      duration: 1500
    });
    api.fetchGet(api.baseUrl + "ask/chat/user/marks", {
      user_id: that.data.uid,
      page: page,
      limit: 10
    }).then(function (res) {
      wx.hideLoading();
      // if (JSON.stringify(res) == "{}") {
      //   return this.setData({
      //     isMore: false,
      //   });
      // }
      if (res.items.length < 10) {
        isMore = false;
      } else {
        page += 1;
      }
      var comments = that.data.userMark.concat(res.items);
      that.setData({
        userMark: comments,
        isMore: isMore,
        page: page
      });
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    var uid = options.uid;
    var res = wx.getSystemInfoSync();
    this.setData({
      windowHeight: res.windowHeight - 40,
      uid: uid
    });
    console.log("uid", this.data.uid);
    this.getChatEvaluateList();
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});