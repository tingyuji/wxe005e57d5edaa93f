var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var api = require('../../utils/api.js');var config = require('../../config.js');var app = getApp();Page({
  data: {
    startDate: '1900-01-01',
    endDate: '',
    valueDate: '',
    // 校验状态 0  -1
    identityStatus: 0,
    // picker状态
    pickerStatus: 0,
    // 再次提示弹窗
    isShowDialog: 0,
    birth: {
      year: 0,
      month: 0,
      day: 0
    },
    uuid: "",
    token: "",
    errMsg: "",
    disabled: false,
    nonage: 0,
    windowWidth: 0,
    windowHeight: 0
  },
  onShow: function onShow() {
    var that = this;
    this.randomDate();
    var nonage = wx.getStorageSync('nonage');
    this.getErrMsg();
    this.getUuid();
    if (!nonage) {
      wx.setStorageSync('nonage', -1);
    }
    wx.getSystemInfo({
      success: function success(res) {
        that.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        });
      }
    });
  },
  onLoad: function onLoad() {
    var endDate = new Date();
    var endYear = endDate.getFullYear();
    var endMonth = endDate.getMonth() + 1 < 10 ? "0".concat(endDate.getMonth() + 1) : endDate.getMonth() + 1;
    var endDay = endDate.getDate();
    var _this$randomDate = this.randomDate(),
      year = _this$randomDate.year,
      month = _this$randomDate.month,
      day = _this$randomDate.day;
    this.setData({
      endDate: "".concat(endYear, "-").concat(endMonth, "-").concat(endDay)
    });
    var nonage = wx.getStorageSync('nonage');
    if (nonage != 1) {
      this.formatTime({
        year: year,
        month: month,
        day: day
      });
    }
    wx.showToast({
      title: '请完成身份校验～',
      icon: 'none',
      duration: 2500
    });
  },
  bindDateChange: function bindDateChange(e) {
    if (this.data.pickerStatus === 0) {
      this.setData({
        pickerStatus: 1
      });
    }
    var date = e.detail.value.split('-');
    var year = date[0];
    var month = date[1];
    var day = date[2];
    this.formatTime({
      year: year,
      month: month,
      day: day
    });
  },
  getErrMsg: function getErrMsg() {
    var that = this;
    var url = api.baseUrl + 'store/weapp/share';
    api.fetchGet(url, {
      noTip: true
    }).then(function (res) {
      var nonage = wx.getStorageSync('nonage');
      that.setData({
        errMsg: res.birthday_notice
      });
      if (nonage === 1) {
        that.setData({
          identityStatus: -1,
          disabled: true
        });
      }
    });
  },
  getUuid: function getUuid() {
    var _this = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
      var that, url;
      return _regeneratorRuntime2().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            that = _this;
            url = "".concat(api.baseUrl, "brapi/token");
            api.fetchGet(url).then(function (res) {
              if (res.msg == '没有迁移数据') {
                that.migrateData(function () {
                  return that.getUuid();
                });
              } else {
                that.fetchUserInfo(res);
                that.setData({
                  uuid: res.profileRepoUuid,
                  token: res.token
                });
              }
            });
          case 3:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }))();
  },
  fetchUserInfo: function fetchUserInfo(data) {
    var that = this;
    var url = "".concat(api.baseUrl, "brapi/me/get?token=").concat(data.token, "&uuid=").concat(data.profileRepoUuid);
    api.fetchGet(url).then(function (resp) {
      var nonage = wx.getStorageSync('nonage');
      var me = resp.me;
      if (nonage === 1) {
        that.setData({
          birth: {
            year: me.birth_y,
            month: me.birth_m,
            day: me.birth_d
          }
        });
      }
    });
  },
  // 迁移数据
  migrateData: function migrateData(callback) {
    var that = this;
    wx.showLoading({
      title: '加载中',
      mask: true
    });
    api.fetchPost("".concat(api.baseUrl, "brapi/migrate")).then(function (resp) {
      if (resp.status == "pending") {
        setTimeout(function () {
          that.migrateData(url, method, params);
        }, 3000);
      } else if (resp.status == "success") {
        wx.hideLoading();
        callback && callback();
      }
    });
  },
  saveBirth: function saveBirth() {
    var _this2 = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
      var token, uuid, url, birth, res;
      return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            token = _this2.data.token;
            uuid = _this2.data.uuid;
            url = "".concat(api.baseUrl, "brapi/me/update?token=").concat(token, "&uuid=").concat(uuid);
            birth = _this2.data.birth;
            _context2.next = 6;
            return api.fetchPut(url, {
              birth_y: Number(birth.year),
              birth_m: Number(birth.month),
              birth_d: Number(birth.day),
              birth_l: 0
            });
          case 6:
            res = _context2.sent;
            if (res.msg === 'success') {
              wx.setStorageSync('nonage', 0);
              // app.setUserInfo(res.me);
              wx.showToast({
                title: '保存成功！',
                icon: 'success'
              });
              wx.navigateBack({
                delta: 1
              });
            } else {
              wx.setStorageSync('nonage', 1);
              _this2.setData({
                disabled: true,
                isShowDialog: 0,
                identityStatus: -1,
                errMsg: res.msg
              });
            }
          case 8:
          case "end":
            return _context2.stop();
        }
      }, _callee2);
    }))();
  },
  showOrHideDialog: function showOrHideDialog(e) {
    var status = e.target.dataset.status;
    this.setData({
      isShowDialog: status
    });
  },
  setErrMsg: function setErrMsg(msg) {
    // let msgArr = msg.split("；");
    this.setData({
      errMsg: msg
    });
  },
  // 修改选中日期（生日）
  formatTime: function formatTime(_ref) {
    var year = _ref.year,
      month = _ref.month,
      day = _ref.day;
    this.setData({
      birth: {
        year: year,
        month: month,
        day: day
      },
      valueDate: "".concat(year, "-").concat(month, "-").concat(day)
    });
  },
  randomDate: function randomDate() {
    var maxdaterandom = new Date().getTime();
    // 由于当前环境为北京GMT+8时区，所以与GMT有8个小时的差值
    var mindaterandom = new Date(1970, 0, 1, 8).getTime();
    var randomdate = this.getRandom(mindaterandom, maxdaterandom);
    var year = new Date(randomdate).getFullYear();
    var month = new Date(randomdate).getMonth() + 1;
    var day = new Date(randomdate).getDate();
    return {
      year: year,
      month: month,
      day: day
    };
  },
  getRandom: function getRandom(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
});