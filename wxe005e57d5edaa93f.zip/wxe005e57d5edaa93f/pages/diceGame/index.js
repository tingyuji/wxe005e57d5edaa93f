var api = require('./../../utils/api.js');var config = require('./../../config.js');var app = getApp();var isSubmit = true;Page({
  data: {
    windowWidth: 0,
    windowHeight: 0,
    system: '',
    isToast: false,
    toastMsg: '',
    pageBottom: 0,
    showTextarea: true,
    disabled: false,
    canClick: true,
    booleanFalse: false,
    inputAnimation: {},
    questionText: '',
    allBallPosition: [{
      anim: 'anim0'
    }, {
      anim: 'anim1'
    }, {
      anim: 'anim2'
    }, {
      anim: 'anim3'
    }, {
      anim: 'anim4'
    }, {
      anim: 'anim5'
    }, {
      anim: 'anim6'
    }],
    showBallPosition: [],
    // 只是内容
    showParsing: false,
    showPayBox: false,
    showCodeBox: false,
    showPayConfigBox: true,
    payConfigArr: [{
      icon: "https://brup.shengri.cn/goods/2017/07/FlULSYrDcwIJumMRDYpIps9SPNPd.png",
      name: "微信",
      payType: 9
    }, {
      icon: "https://brup.shengri.cn/goods/2017/07/FotSXy4BdkO3aGlZcWC85wYXxmaG.png",
      name: "管家钱包",
      payType: 28,
      amount: 0
    }],
    priceArr: [
      // {
      //     coupon_id: 123,
      //     is_default: 0,
      //     is_recommend: 0,
      //     explain: '至少高等级达人解答'
      // },
      // {
      //     price: 300,
      //     is_default: 0,
      //     is_recommend: 0,
      //     explain: '至少高等级达人解答'
      // },
      // {
      //     price: 900,
      //     is_default: 1,
      //     is_recommend: 1,
      //     explain: '获得更多高等级达人解答'
      // }
    ],
    choosePrice: 900,
    walletBalanceText: '余额：',
    postId: 0,
    codeDesc: '再发一次',
    walletParce: 0,
    ticketCode: '',
    orderId: '',
    code: '',
    //掷骰子 状态
    operateStatus: 0,
    hasPlayEntranceAnimation: false
  },
  onLoad: function onLoad(options) {
    if (app.isLogin()) {
      if (wx.getStorageSync('dice_questionText')) {
        var questionText = wx.getStorageSync('dice_questionText');
        var showBallPosition = wx.getStorageSync('diceResultData');
        this.setData({
          questionText: questionText,
          operateStatus: 2,
          showBallPosition: showBallPosition
        });
        wx.removeStorageSync('dice_questionText');
      }
    }
    console.log('showTextarea >>>>>> ' + this.data.showTextarea);
  },
  onShow: function onShow() {
    var that = this;
    isSubmit = true;
    wx.getSystemInfo({
      success: function success(res) {
        that.setData({
          system: res.system,
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        });
      }
    });
    if (this.data.showBallPosition.length <= 0) {
      that.setData({
        operateStatus: 0
      });
    }
    if (app.isLogin()) {
      this.fetchCouponNum();
    }
    this.fetchData();
    console.log('showTextarea >>>>>> ' + this.data.showTextarea);
  },
  onReady: function onReady() {
    var _this = this;
    var that = this;
    if (wx.startDeviceMotionListening && wx.onDeviceMotionChange) {
      var SHAKE_THRESHOLD = 5000;
      var last_update = 0;
      var x = 0;
      var y = 0;
      var z = 0;
      var last_x = 0;
      var last_y = 0;
      var last_z = 0;
      wx.startDeviceMotionListening({
        success: function success() {},
        fail: function fail() {},
        complete: function complete() {}
      });
      wx.onDeviceMotionChange(function (_ref) {
        var alpha = _ref.alpha,
          beta = _ref.beta,
          gamma = _ref.gamma;
        var curTime = new Date().getTime();
        if (curTime - last_update > 100) {
          var diffTime = curTime - last_update;
          last_update = curTime;
          x = alpha;
          y = beta;
          z = gamma;
          var speed = Math.abs(x + y + z - last_x - last_y - last_z) / diffTime * 10000;
          if (speed > SHAKE_THRESHOLD) {
            if (that.data.operateStatus != 0) {
              return;
            }
            // wx.vibrateLong();
            _this.shakeFn();
          }
          last_x = x;
          last_y = y;
          last_z = z;
        }
      });
    }
    this.tarotPay = this.selectComponent("#tarotPay");
    this.consultDialog = this.selectComponent("#consultDialog");
    console.log('showTextarea >>>>>> ' + this.data.showTextarea);
  },
  onUnload: function onUnload() {
    if (wx.stopDeviceMotionListening) {
      wx.stopDeviceMotionListening();
    }
    this.setData({
      operateStatus: 0
    });
  },
  fetchCouponNum: function fetchCouponNum() {
    var that = this;
    api.fetchGet(api.baseUrl + 'ask/invite/lists', {}).then(function (res) {});
  },
  setImages: function setImages() {
    var imagesArr = [];
    var showBallPosition = this.data.showBallPosition;
    showBallPosition.forEach(function (v, k) {
      imagesArr.push({
        id: v.info.id,
        url: v.info.url,
        width: v.info.width,
        height: v.info.height,
        orientation: v.info.orientation
      });
    });
    return imagesArr;
  },
  // 点击游戏开始
  gameOperate: function gameOperate(e) {
    var that = this;
    if (!that.data.canClick) return;
    if (app.checkLoginStatus()) {
      that.setData({
        canClick: false
      });
      that.shakeFn();
      // 初始化数据
      this.tarotPay.initData();
      this.consultDialog.initData();
    }
  },
  //获取骰子详情
  fetchData: function fetchData() {
    var that = this;
    var url = api.baseUrl + 'brapi/shaizi/detail';
    api.fetchGet(url).then(function (res) {
      that.bagBallAnimationFn(res.result);
    });
  },
  bagBallAnimationFn: function bagBallAnimationFn(data) {
    var that = this;
    var allBallPosition = that.data.allBallPosition;
    var showBallPosition = that.getArrayItems(allBallPosition, 3);
    data.forEach(function (v, k) {
      showBallPosition[k].info = v;
    });
    setTimeout(function () {
      that.setData({
        showBallPosition: showBallPosition
      });
      wx.setStorageSync('diceResultData', showBallPosition);
    }, 530);
  },
  // 展示解析弹框
  showParsingFn: function showParsingFn() {
    var that = this;
    that.setData({
      showParsing: !that.data.showParsing,
      showTextarea: !that.data.showTextarea,
      disabled: !that.data.disabled
    });
    console.log('showTextarea >>>>>> ' + this.data.showTextarea);
  },
  showPayCom: function showPayCom() {
    return this.tarotPay.showPay();
  },
  // 使用提问券支付
  useCouponPay: function useCouponPay(e) {
    return this.tarotPay.useCouponPay(e.detail);
  },
  getArrayItems: function getArrayItems(arr, num) {
    //新建一个数组,将传入的数组复制过来,用于运算,而直接操作传入的数组;
    var tempArray = new Array();
    for (var index in arr) {
      tempArray.push(arr[index]);
    }
    //取出的数值项,保存在此数组
    var returnArray = new Array();
    for (var i = 0; i < num; i++) {
      //判断如果数组还有可以取出的元素,以防下标越界
      if (tempArray.length > 0) {
        //在数组中产生一个随机索引
        var arrIndex = Math.floor(Math.random() * tempArray.length);
        //将此随机索引的对应的数组元素值复制出来
        returnArray[i] = tempArray[arrIndex];
        //然后删掉此索引的数组元素,这时候tempArray变为新的数组
        tempArray.splice(arrIndex, 1);
      } else {
        //数组中数据项取完后,退出循环,比如数组本来只有10项,但要求取出20项.
        break;
      }
    }
    return returnArray;
  },
  noClose: function noClose() {
    return;
  },
  showPayBoxFn: function showPayBoxFn(e) {
    var that = this;
    if (that.data.questionText.length < 5) {
      return wx.showToast({
        title: '提问不得少于5个字',
        icon: 'none',
        duration: 800
      });
    }
    this.setData({
      showTextarea: false,
      disabled: true
    });
    console.log('showTextarea >>>>>> ' + this.data.showTextarea);
    this.tarotPay.setPayParams({
      circle_id: 33,
      type: 2,
      content: this.data.questionText,
      images: this.setImages(),
      is_anonymous: 0
    });
    this.consultDialog.setQuestionText(this.data.questionText);
    this.consultDialog.showDialog();
  },
  hideDialog: function hideDialog() {
    this.setData({
      showTextarea: true,
      disabled: false
    });
    console.log('showTextarea >>>>>> ' + this.data.showTextarea);
  },
  jump: function jump() {
    wx.navigateTo({
      url: '../diceInstructions/index'
    });
  },
  inputQuestion: function inputQuestion(e) {
    this.setData({
      questionText: e.detail.value
    });
  },
  //开始摇一摇
  shakeFn: function shakeFn() {
    var that = this;
    if (that.data.operateStatus !== 0) {
      return;
    }
    that.setData({
      operateStatus: 1
    });
    setTimeout(function () {
      that.setData({
        operateStatus: 2
      });
    }, 3300);
  },
  focus: function focus(e) {
    var animation = wx.createAnimation({
      transformOrigin: "0 100%",
      duration: 300,
      timingFunction: "linear",
      delay: 0
    });
    animation.bottom(e.detail.height).step();
    this.setData({
      // pageBottom: e.detail.height * 2
      inputAnimation: animation.export()
    });
  },
  blur: function blur() {
    this.setData({
      pageBottom: 0
    });
  }
});