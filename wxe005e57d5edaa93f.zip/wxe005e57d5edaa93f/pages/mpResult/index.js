var api = require("./../../utils/api.js");var app = getApp();Page({
  /**
   * 页面的初始数据
   */
  data: {
    chatList: [],
    qid: "",
    oid: "",
    result: [],
    contentArray: [],
    hasLogin: false,
    status: 0,
    statusBarHeight: 0,
    navTop: 0,
    navHeight: 0
  },
  getChat: function getChat() {
    var that = this;
    var userInfo = app.globalData.userInfo;
    if (userInfo != null && "tok" in userInfo) {
      api.fetchGet(api.baseUrl + "ask/chat/recommend_list", {
        type: 11,
        page: 0
      }).then(function (res) {
        var chatList = res.items.slice(0, 5);
        that.setData({
          chatList: chatList,
          hasLogin: true
        });
      });
    } else {
      api.fetchGet(api.baseUrl + "s/chat/smallapp/recommends").then(function (res) {
        that.setData({
          chatList: res.items,
          hasLogin: false
        });
      });
    }
  },
  getReversoDetail: function getReversoDetail() {
    var _this = this;
    var that = this;
    api.fetchGet(api.baseUrl + "tp/reverso/detail", {
      question_id: this.data.qid,
      option_id: this.data.oid
    }).then(function (res) {
      var arr = [];
      if (res.status) {
        var content = res.content;
        content = content.split("\n");
        content.forEach(function (v, j) {
          arr.push(v.replace(/\\n/g, "\n"));
        });
      }
      _this.setData({
        result: res,
        contentArray: arr,
        status: res.status
      });
    });
  },
  handleAsk: function handleAsk() {
    wx.navigateTo({
      url: "../tarotGame/index"
    });
  },
  handleReturn: function handleReturn() {
    wx.navigateBack({
      delta: 1
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    // console.log("options------------------->", options);
    var res = wx.getSystemInfoSync();
    console.log("res--->", res);
    var menuButtonObject = wx.getMenuButtonBoundingClientRect();
    var navTop = menuButtonObject.top;
    var navHeight = menuButtonObject.height + (menuButtonObject.top - res.statusBarHeight) * 2; //导航高度
    this.setData({
      qid: options.qid,
      oid: options.oid,
      statusBarHeight: res.statusBarHeight,
      navTop: navTop,
      navHeight: navHeight
    });
    this.getChat();
    this.getReversoDetail();
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});