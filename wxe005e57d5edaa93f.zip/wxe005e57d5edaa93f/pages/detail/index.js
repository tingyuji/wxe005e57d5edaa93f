require("../../@babel/runtime/helpers/Arrayincludes");var api = require("./../../utils/api.js");var app = getApp();var timeOut, refreshTimeOut;var innerAudioContext;Page({
  data: {
    windowWidth: 0,
    windowHeight: 0,
    showDownloadPrompt: false,
    showDownloadTimeout: false,
    showInvitationMask: false,
    downloadPromptText: "下载问问塔罗可解锁第二个答案",
    showPage: false,
    showIco: false,
    showEvaluationBox: false,
    postId: 0,
    dataQA: {},
    commentsData: [],
    currentAudio: 999,
    userUid: 0,
    helpFriendsData: {},
    showIntroducePop: false,
    introduceTextData: [["这里用到的是“圣三角占卜法”，", "用于占卜是否两难的问题"], ["抽取的三张牌分别代表：", "过去、现在、未来"], ["第一张：代表过去的经验"], ["第二张：代表本人问题的现状"], ["第三张：代表对问题将来的预测结果"], ["真人占卜师在线为你答疑，您会得到至少", "两位占卜师的解答，如有疑问可以和占卜师", "连麦"]],
    showIntroduceTextData: [],
    fetchConsumeCnt: false,
    //判断是否请求当日消费单数
    showConsumePrompt: false,
    downloadConsumeText: "下载问问塔罗app即可体验与占卜师连麦进行占卜服务(回复“下载”即可获得5分钟免费连麦时长)",
    platform: "",
    msgImage: "https://static.shengri.cn/uploads/QA_mp/tarot_banner.jpeg?imageslim",
    // 当前播放 audio index
    clickIndex: 0,
    hasSensitive: false
  },
  onShareAppMessage: function onShareAppMessage(res) {
    var that = this;
    var shareData = that.data.helpFriendsData.share;
    return {
      title: shareData.title,
      path: "pages/index/index?inviteUserId=" + app.globalData.userInfo.uid,
      imageUrl: shareData.img
    };
  },
  onLoad: function onLoad(options) {
    var that = this;
    this.setData({
      postId: options.postId,
      fetchConsumeCnt: options.fetchConsumeCnt || false
    });
    if (!app.isLogin()) {
      if (app.getAllow()) {
        wx.navigateTo({
          url: "../login/login"
        });
      } else {
        wx.navigateTo({
          url: "../authorization/authorization"
        });
      }
      return;
    }
    this.fetchData(options.postId);
    this.fetchTemplateIds();
    if (options.fetchConsumeCnt) {
      setTimeout(function () {
        that.fetchCnt();
      }, 2000);
    }
    innerAudioContext = wx.createInnerAudioContext();
    innerAudioContext.onPlay(function () {
      that.audioOnPlay();
    });
    innerAudioContext.onEnded(function () {
      that.audioOnEnded();
    });
  },
  onShow: function onShow(options) {
    var that = this;
    this.commentData(this.data.postId);
    wx.getSystemInfo({
      success: function success(res) {
        that.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth,
          platform: res.platform
        });
      }
    });
    // 从搜索直接进入的页面
    if (getCurrentPages().length == 1) {
      this.setData({
        showIco: true
      });
    }
    if (wx.getStorageSync("postId")) {
      that.fetchData(wx.getStorageSync("postId"));
      that.commentData(wx.getStorageSync("postId"));
    }
    if (app.globalData.userInfo && app.globalData.userInfo.uid) {
      that.setData({
        userUid: app.globalData.userInfo.uid,
        currentAudio: 999
      });
    }
  },
  onHide: function onHide() {
    clearTimeout(refreshTimeOut);
    innerAudioContext.stop();
  },
  onUnload: function onUnload() {
    clearTimeout(refreshTimeOut);
    innerAudioContext.destroy();
    wx.removeStorageSync("postId");
    wx.removeStorageSync("commentIndex");
    wx.removeStorageSync("commentsData");
  },
  noclose: function noclose() {
    return;
  },
  fetchData: function fetchData(postId) {
    var that = this;
    wx.showToast({
      title: "加载中...",
      icon: "loading",
      duration: 10000
    });
    api.fetchGet(api.baseUrl + "ask/postsInfo/" + postId).then(function (res) {
      // 助力好友的数据
      api.fetchGet(api.baseUrl + "ask/assistance/lists", {
        post_id: postId
      }).then(function (resp) {
        wx.hideToast();
        var showInvitationMask = false;
        if (res.data.show_cover) {
          showInvitationMask = true;
        }
        console.log(res.data);
        that.setData({
          showInvitationMask: showInvitationMask,
          helpFriendsData: resp,
          dataQA: res.data,
          showPage: true
        });
        if (res.data.show_data_time) {
          that.settime(res.data.show_data_time);
        }
        that.justifySensitive(res.data);
      });
    });
  },
  fetchCnt: function fetchCnt() {
    var that = this;
    var platform = this.data.platform;
    api.fetchGet(api.baseUrl + "ask/consume/count").then(function (res) {
      if (res.count == 2) {
        that.setData({
          showConsumePrompt: true,
          downloadPromptText: platform == "ios" ? "下载“问问塔罗-塔罗牌占卜爱情星座运势”APP即可体验与占卜师连麦进行占卜服务(回复“下载”即可获得5分钟免费连麦时长)" : "下载“问问塔罗”APP即可体验与占卜师连麦进行占卜服务(回复“下载”即可获得5分钟免费连麦时长)"
        });
      }
    });
  },
  commentData: function commentData(postId) {
    var that = this;
    api.fetchGet(api.baseUrl + "ask/" + postId + "/comments", {
      owner: 0,
      sort: "asc"
    }).then(function (res) {
      var tempData = res.items;
      var showEvaluationBox = false;
      var commentIndex = wx.getStorageSync("commentIndex");
      tempData.forEach(function (v, k) {
        v.isPlay = false;
      });
      // 是否弹起来直接好评弹框
      if (commentIndex.has) {
        if (!res.items[commentIndex.index].is_marked) {
          showEvaluationBox = true;
        }
      }
      that.setData({
        showEvaluationBox: showEvaluationBox,
        commentsData: tempData
      });
    });
  },
  // 倒计时
  settime: function settime(val) {
    var that = this;
    if (val <= 0) {
      wx.redirectTo({
        url: "../detail/index?postId=" + that.data.postId
      });
    } else {
      val = val - 1;
      that.setData({
        "dataQA.show_data_time": val
      });
      refreshTimeOut = setTimeout(function () {
        that.settime(val);
      }, 1000);
    }
  },
  // 播放语音
  playAudio: function playAudio(e) {
    var that = this;
    var operate = e.currentTarget.dataset.operate;
    var index = e.currentTarget.dataset.index;
    var helpNum = that.data.helpFriendsData.num;
    var helpTotalNum = that.data.helpFriendsData.total_num;
    var commentId = e.currentTarget.dataset.commentid;
    // 助力消息推送埋点
    var formId = e.detail.formId;
    var openId = app.globalData.wxInfo.openId;
    this.setData({
      clickIndex: index
    });
    if (that.checkLoginStatus()) {
      /**
       * show_cover: 展示邀请弹框
       * download：展示下载弹框
       * timeout：展示过期弹框
       */
      if (operate == "show_cover") {
        api.fetchPost(api.baseUrl + "wechat/saveformdata", {
          open_id: openId,
          form_id: formId,
          context: {
            type: 1
          },
          noTip: true
        }).then(function (res) {});
        wx.showModal({
          title: "提示",
          content: "未完成助力，帖子已过期~",
          showCancel: false,
          confirmColor: "#ff3939",
          success: function success(res) {}
        });
        // that.setData({
        //   showInvitationMask: true
        // })
        return;
      } else if (operate == "download") {
        api.fetchPost(api.baseUrl + "wechat/saveformdata", {
          open_id: openId,
          form_id: formId,
          context: {
            type: 1
          },
          noTip: true
        }).then(function (res) {});
        that.statisticalSecondSound();
        that.setData({
          showDownloadTimeout: true,
          downloadPromptText: "下载问问塔罗可解锁第二个答案"
        });
        return;
      } else if (operate == "timeout") {
        wx.showModal({
          title: "提示",
          content: "24小时内未完成助力，帖子已过期~",
          showCancel: false,
          confirmColor: "#ff3939",
          success: function success(res) {}
        });
        return;
      }
      // 收听的动作

      var isListen = e.currentTarget.dataset.islisten;
      if (!isListen) {
        wx.showToast({
          title: "该音频不允许旁听",
          icon: "none",
          duration: 800
        });
        return;
      } else {
        this.checkAudioStatus(helpNum, helpTotalNum, commentId);
      }
    }
  },
  checkAudioStatus: function checkAudioStatus(helpNum, helpTotalNum, commentId) {
    var that = this;
    var audioSrc;
    var commentsData = that.data.commentsData;
    var index = that.data.clickIndex;
    if (index === that.data.currentAudio) {
      if (commentsData[index].isPlay) {
        innerAudioContext.pause();
        commentsData[index].currentText = "已暂停";
        commentsData[index].isPlay = false;
        that.setData({
          commentsData: commentsData
        });
      } else {
        commentsData[index].currentText = "正在播放";
        commentsData[index].isPlay = true;
        innerAudioContext.play();
        that.setData({
          commentsData: commentsData
        });
      }
    } else {
      commentsData.forEach(function (v, k) {
        commentsData[k].isPlay = false;
        if (k == index) {
          commentsData[k].currentText = "正在缓存";
        } else {
          commentsData[k].currentText = null;
        }
      });
      that.setData({
        commentsData: commentsData
      });
      innerAudioContext.stop();
      api.fetchGet(api.baseUrl + "forum/posts/" + commentId + "/audio", {
        noTip: true
      }).then(function (res) {
        audioSrc = res.date.resource_url;
        innerAudioContext.src = audioSrc;
        innerAudioContext.obeyMuteSwitch = false;
        innerAudioContext.autoplay = true;
        innerAudioContext.play();
      });
    }
    that.setData({
      currentAudio: index
    });
  },
  audioOnPlay: function audioOnPlay() {
    var that = this;
    var index = this.data.clickIndex;
    var commentsData = this.data.commentsData;
    commentsData[index].currentText = "正在播放";
    commentsData[index].isPlay = true;
    that.setData({
      commentsData: commentsData
    });
  },
  audioOnEnded: function audioOnEnded() {
    var that = this;
    var index = this.data.clickIndex;
    var commentsData = this.data.commentsData;
    commentsData[index].currentText = null;
    commentsData[index].isPlay = false;
    that.setData({
      commentsData: commentsData
    });
    if (that.data.userUid == commentsData[index].reply_to_uid && !commentsData[index].is_marked) {
      wx.setStorageSync("commentsData", commentsData[index]);
      wx.setStorageSync("postId", that.data.postId);
      wx.setStorageSync("commentIndex", {
        has: true,
        index: index
      });
      wx.navigateTo({
        url: "../evaluate/index"
      });
    }
  },
  // 邀请分享统计
  shareStatistics: function shareStatistics() {
    var that = this;
    api.fetchPost(api.baseUrl + "ask/assistance/" + that.data.postId + "/share", {
      post_id: that.data.postId
    }).then(function (res) {});
  },
  // 提交对大师的评价
  submitEvaluate: function submitEvaluate() {
    var that = this;
    var commentIndex = wx.getStorageSync("commentIndex").index;
    var commentId = that.data.commentsData[commentIndex].comment_id;
    wx.showToast({
      title: "提交中...",
      icon: "loading",
      duration: 10000
    });
    api.fetchPost(api.baseUrl + "ask/marking/" + commentId, {
      star: 4
    }).then(function (res) {
      wx.hideToast();
      that.setData({
        showEvaluationBox: false
      });
      wx.removeStorageSync("postId");
      wx.removeStorageSync("commentIndex");
      wx.removeStorageSync("commentsData");
      that.commentData(that.data.postId);
    });
  },
  // 进入评价页面
  goEvaluate: function goEvaluate() {
    wx.navigateTo({
      url: "../evaluate/index"
    });
  },
  // 检查登录状态
  checkLoginStatus: function checkLoginStatus() {
    // 如果没有登录，就去登录授权
    if (!app.isLogin()) {
      if (app.getAllow()) {
        wx.navigateTo({
          url: "../login/login"
        });
      } else {
        wx.navigateTo({
          url: "../authorization/authorization"
        });
      }
      return;
    }
    return true;
  },
  // 展示下载提示
  promptDownload: function promptDownload() {
    // this.setData({
    //   showDownloadPrompt: true,
    // });
    wx.navigateTo({
      url: "../leadDownload/index"
    });
  },
  // 取消下载，关闭弹窗
  cancel: function cancel() {
    this.setData({
      showDownloadPrompt: false,
      showDownloadTimeout: false,
      showConsumePrompt: false
    });
  },
  // 统计点击下载
  statisticalClickDown: function statisticalClickDown() {
    console.log("------");
    // 没用作用，只是为了统计点击下载量
  },
  // 统计点击第二条语音
  statisticalSecondSound: function statisticalSecondSound() {
    console.log("*******");
    // 没有作用，只是为了统计点击助力的第二条语音
  },
  // 点击邀请好友的埋点
  inviteFriendFn: function inviteFriendFn(e) {
    // 助力消息推送埋点
    var formId = e.detail.formId;
    var openId = app.globalData.wxInfo.openId;
    console.log(formId);
    this.shareStatistics();
    api.fetchPost(api.baseUrl + "wechat/saveformdata", {
      open_id: openId,
      form_id: formId,
      context: {
        type: 1
      },
      noTip: true
    }).then(function (res) {});
  },
  // 关闭邀请好友的弹窗
  closeInvitationMask: function closeInvitationMask() {
    this.setData({
      showInvitationMask: false
    });
  },
  // 进入首页
  jumpIndedx: function jumpIndedx() {
    wx.switchTab({
      url: "../index/index"
    });
  },
  // 展示塔罗说明动画提示
  showIntroducePopFn: function showIntroducePopFn(num) {
    var that = this;
    var introduceTextData = that.data.introduceTextData;
    var showIntroduceTextData = JSON.parse(JSON.stringify(that.data.showIntroduceTextData));
    if (showIntroduceTextData.length > 5) return;
    num = typeof num == "number" ? num : 0;
    timeOut = setTimeout(function () {
      if (num > 5) return;
      showIntroduceTextData.push(introduceTextData[num]);
      that.setData({
        showIntroducePop: true,
        showIntroduceTextData: showIntroduceTextData
      });
      num = num - 0 + 1;
      that.showIntroducePopFn(num);
    }, 1000);
  },
  // 关闭塔罗说明动画弹窗
  closeIntroducePop: function closeIntroducePop() {
    clearTimeout(timeOut);
    this.setData({
      showIntroducePop: false,
      showIntroduceTextData: []
    });
  },
  fetchTemplateIds: function fetchTemplateIds() {
    var that = this;
    api.fetchGet(api.baseUrl + "wxapp/templateIds", {
      business: "new_response_notification"
    }).then(function (res) {
      that.setData({
        templateIds: res.templateIds
      });
    });
  },
  applySubMsg: function applySubMsg() {
    var that = this;
    app.applySubMsg(this.data.templateIds, that.data.postId);
  },
  handleChatInfo: function handleChatInfo(e) {
    if (app.checkLoginStatus()) {
      var uid = e.currentTarget.dataset.uid;
      wx.navigateTo({
        url: "../chatInfo/index?uid=" + uid
      });
    }
  },
  //敏感词校验
  justifySensitive: function justifySensitive(data) {
    var content = data.content;
    if (content.includes("*")) {
      this.setData({
        hasSensitive: true
      });
    }
  }
});