var api = require("./../../utils/api.js");var app = getApp();var innerAudioContext;Page({
  /**
   * 页面的初始数据
   */
  data: {
    ChatBasisInfo: {},
    ChatEvaluate: {},
    uid: "",
    current: "",
    showData: false,
    //展示完整问答评价
    hasAdd: false,
    //是否关注了达人
    clickIndex: "",
    //用于传递
    currentIndex: -1,
    //用于判断
    audio: {},
    is_follow: 0,
    follower_cnt: 0,
    // anim: "",
    navHeight: 0,
    statusBarHeight: 0,
    userMark: [],
    //加载更多评价
    page: 1,
    isMore: true
    // showSignature: false, //是否完整的展示个人简介
  },

  onLoad: function onLoad(options) {
    var _this = this;
    this.setData({
      uid: options.uid
    });
    //播放语音
    // innerAudioContext = wx.createInnerAudioContext();
    // innerAudioContext.onPlay(() => {
    //   this.audioOnPlay();
    // });
    // innerAudioContext.onEnded(() => {
    //   this.audioOnEnded();
    // });
    //自定义导航栏的高度 ：1、获取statusBarHeight 2、导航高度
    var menuButton = wx.getMenuButtonBoundingClientRect();
    wx.getSystemInfo({
      success: function success(res) {
        var statusBarHeight = res.statusBarHeight;
        //胶囊距离顶部的距离
        var navTop = menuButton.top;
        var navHeight = (navTop - statusBarHeight) * 2 + menuButton.height;
        _this.setData({
          navHeight: navHeight,
          statusBarHeight: statusBarHeight
        });
      }
    });
  },
  onReady: function onReady() {
    this.follower = this.selectComponent("#follower");
  },
  onShow: function onShow() {
    this.getChatBasisInfo();
    this.getChatEvaluate();
    this.getChatEvaluateList();
  },
  //达人基础信息
  getChatBasisInfo: function getChatBasisInfo() {
    var that = this;
    api.fetchGet(api.baseUrl + "forum/profile", {
      uid: that.data.uid
    }).then(function (res) {
      // let audio = res.audio;
      // audio.isPlay = false;
      // that.setData({
      //   ChatBasisInfo: res,
      //   audio: audio,
      // });
      if (res.official_certification) {
        var officalItems = res.official_certification.items;
        var officialArray = {
          塔罗: {
            backgroundColor: "rgba(255,221,23,0.2)",
            color: "#FFDD17",
            rankLogo: "https://static.tttarot.com/mini_app/images/mini_tarot/chatInfo/skill-icon.png"
          },
          星盘: {
            backgroundColor: "rgba(234,97,204,0.2)",
            color: "#EA61CC",
            rankLogo: "https://static.tttarot.com/mini_app/images/mini_tarot/chatInfo/rank-logo-astro.png"
          },
          骰子: {
            backgroundColor: "rgba(47,222,216,0.2)",
            color: "#2FDED8",
            rankLogo: "https://static.tttarot.com/mini_app/images/mini_tarot/chatInfo/rank-logo-dice.png"
          },
          直播: {
            backgroundColor: "rgba(82,197,255,0.2)",
            color: "#52C5FF",
            rankLogo: "https://static.tttarot.com/mini_app/images/mini_tarot/chatInfo/living-logo.png",
            icon: "https://static.tttarot.com/mini_app/images/mini_tarot/chatInfo/living-icon.png"
          }
        };
        var starArray = {
          五星: 5,
          四星: 4,
          三星: 3,
          两星: 2,
          一星: 1
        };
        var officalItemsResult = officalItems.map(function (v, k) {
          v.starCount = starArray[v.level_name];
          return Object.assign({}, v, officialArray[v.name]);
        });
        res.official_certification.items = officalItemsResult;
      }
      that.setData({
        ChatBasisInfo: res,
        // audio: audio,
        follower_cnt: res.follower_cnt,
        is_follow: res.is_follow
      });
    });
  },
  // 达人评价
  getChatEvaluate: function getChatEvaluate() {
    var that = this;
    api.fetchGet(api.baseUrl + "ask/chat/profile", {
      user_id: that.data.uid
    }).then(function (res) {
      that.setData({
        ChatEvaluate: res
      });
    });
  },
  handleBindChange: function handleBindChange(e) {
    var _e$detail = e.detail,
      current = _e$detail.current,
      source = _e$detail.source;
    if (source === "autoplay" || source === "touch") {
      this.setData({
        current: current
      });
    }
  },
  //展开数据
  openData: function openData() {
    this.setData({
      showData: true
    });
  },
  //收起
  closeData: function closeData() {
    this.setData({
      showData: false
    });
  },
  //关注
  handleFollow: function handleFollow(e) {
    var _this2 = this;
    var uid = e.currentTarget.dataset.uid;
    var follower_cnt = this.data.follower_cnt;
    var is_follow = this.data.is_follow;
    api.fetchPost(api.baseUrl + "forum/following/".concat(uid)).then(function (res) {
      var anim = "anim";
      follower_cnt += 1;
      is_follow = 1;
      _this2.setData({
        anim: anim,
        hasAdd: true,
        is_follow: is_follow,
        follower_cnt: follower_cnt
      });
    });
    this.follower.open();
    // this.getChatBasisInfo();
  },
  //取消关注
  handleCancelFollow: function handleCancelFollow(e) {
    var _this3 = this;
    var uid = e.currentTarget.dataset.uid;
    var follower_cnt = this.data.follower_cnt;
    var is_follow = this.data.is_follow;
    api.fetchDelete(api.baseUrl + "forum/following/".concat(uid)).then(function (res) {
      var anim = "anim";
      follower_cnt -= 1;
      is_follow = 0;
      _this3.setData({
        anim: anim,
        hasAdd: true,
        is_follow: is_follow,
        follower_cnt: follower_cnt
      });
    });
    wx.showToast({
      title: "取消关注",
      icon: "none",
      duration: 1500
    });
    // this.getChatBasisInfo();
  },
  //返回
  handleReturn: function handleReturn() {
    wx.navigateBack();
  },
  // 跳转查看更多评价
  handleMoreEvaluate: function handleMoreEvaluate() {
    // console.log(this.data.uid);
    wx.navigateTo({
      url: "../comments/index?uid=" + this.data.uid
    });
  },
  // 点击播放语音
  playAudio: function playAudio() {
    var that = this;
    var audioData = that.data.audio;
    innerAudioContext.src = audioData.audio_url;

    //判断currentIndex与index是否相等
    if (audioData.isPlay) {
      audioData.isPlay = false;
      innerAudioContext.pause();
    } else {
      audioData.isPlay = true;
      innerAudioContext.play();
    }
    this.setData({
      audio: audioData
    });
  },
  audioOnPlay: function audioOnPlay() {
    var audioData = this.data.audio;
    audioData.isPlay = true;
    this.setData({
      audio: audioData
    });
  },
  audioOnEnded: function audioOnEnded() {
    var audioData = this.data.audio;
    audioData.isPlay = false;
    this.setData({
      audio: audioData
    });
  },
  // 连麦评价接口
  getChatEvaluateList: function getChatEvaluateList() {
    var that = this;
    api.fetchGet(api.baseUrl + "ask/chat/user/marks", {
      user_id: that.data.uid,
      page: 0,
      limit: 5
    }).then(function (res) {
      that.setData({
        userMark: res.items
      });
    });
  },
  handleDownLoad: function handleDownLoad() {
    wx.navigateTo({
      url: "../leadDownload/index"
    });
  },
  handleFresh: function handleFresh() {
    var that = this;
    var page = that.data.page;
    var isMore = that.data.isMore;
    if (!isMore) {
      return;
    }
    wx.showToast({
      title: "加载中",
      icon: "loading",
      duration: 300
    });
    api.fetchGet(api.baseUrl + "ask/chat/user/marks", {
      user_id: that.data.uid,
      page: page,
      limit: 10
    }).then(function (res) {
      if (res.items.length < 10 || res.items.length == 0) {
        isMore = false;
      } else {
        page += 1;
      }
      var list = that.data.userMark.concat(res.items);
      that.setData({
        isMore: isMore,
        page: page,
        userMark: list
      });
    });
  },
  // handleShowSign() {
  //   this.setData({
  //     showSignature: true,
  //   });
  // },
  // handleCloseSign() {
  //   this.setData({
  //     showSignature: false,
  //   });
  // },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {
    // innerAudioContext.stop();
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {
    // innerAudioContext.destroy();
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {},
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function onShareAppMessage() {}
});