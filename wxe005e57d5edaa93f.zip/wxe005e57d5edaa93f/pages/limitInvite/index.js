var api = require("./../../utils/api.js");var app = getApp();Page({
  /**
   * 页面的初始数据
   */
  data: {
    ruleContent: ["1.邀请好友提问券上限10张，多邀请不会发放提问券。提问券有效期24小时。", "2.被邀请人必须为真实新注册用户，否则邀请不通过，并且提问券不发放。"],
    scrollHeight: "",
    //邀请列表的高度
    inviteList: [],
    hasLogin: false,
    //判断是否登录了
    rankTop: [{}, {}, {}] //前三排行榜
  },
  onShareAppMessage: function onShareAppMessage() {
    var hasLogin = this.data.hasLogin;
    return {
      title: "无限次免费问感情事业等问题，专业占卜师在线解惑",
      path: hasLogin ? "pages/index/index?inviteUserId=" + app.globalData.userInfo.uid : "pages/index/index",
      imageUrl: "https://static.shengri.cn/uploads/QA_mp/InvitedShare@2x-1.png?imageslim"
    };
  },
  doLogin: function doLogin() {
    return app.checkLoginStatus();
  },
  //查看记录
  handleRecords: function handleRecords() {
    if (app.checkLoginStatus()) {
      wx.navigateTo({
        url: "../../pages/inviteRecord/index"
      });
    }
  },
  //获取邀请奖励列表
  //邀请记录
  fetchInviteList: function fetchInviteList() {
    var that = this;
    api.fetchGet(api.baseUrl + "ask/invite/all/list", {
      ownstatus: 0
    }).then(function (res) {
      that.setData({
        inviteList: res.items
      });
    });
  },
  //获取排行榜
  getRankingList: function getRankingList() {
    var that = this;
    api.fetchGet(api.baseUrl + "ask/invite/week_top_list", {
      limit: 10,
      page: 0
    }).then(function (res) {
      var items = res.items.items.slice(0, 3);
      that.setData({
        rankTop: items
      });
    });
  },
  handleSearchRankList: function handleSearchRankList() {
    wx.navigateTo({
      url: "../rankingList/index"
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    var screen = wx.getSystemInfoSync();
    this.setData({
      scrollHeight: screen.windowHeight - 423
    });
    this.fetchInviteList();
    this.getRankingList();
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {
    var isLogin = app.loginStatus();
    this.setData({
      hasLogin: isLogin
    });
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {}
});