var api = require("./../../utils/api.js");var app = getApp();Page({
  /**
   * 页面的初始数据
   */
  data: {
    page: 1,
    dataMore: false,
    //是否有更多的数据
    noMore: false,
    inviteList: []
  },
  onShareAppMessage: function onShareAppMessage() {
    return {
      title: "无限次免费问感情事业等问题，专业占卜师在线解惑",
      path: "pages/index/index?inviteUserId=" + app.globalData.userInfo.uid,
      imageUrl: "https://static.shengri.cn/uploads/QA_mp/InvitedShare@2x-1.png?imageslim"
    };
  },
  //邀请记录
  fetchRecords: function fetchRecords() {
    var that = this;
    api.fetchGet(api.baseUrl + "ask/invite/all/list", {
      ownstatus: 1
    }).then(function (res) {
      that.setData({
        inviteList: res.items
      });
      console.log(that.data.inviteList);
    });
  },
  loadMore: function loadMore() {
    var that = this;
    that.setData({
      dataMore: true,
      noMore: false
    });
    api.fetchGet(api.baseUrl + "ask/invite/all/list", {
      ownstatus: 1,
      page: that.data.page
    }).then(function (res) {
      var list = that.data.inviteList.concat(res.items);
      if (res.items.length == 0) {
        that.setData({
          noMore: true,
          dataMore: false
        });
      } else {
        that.setData({
          dataMore: true,
          noMore: false,
          inviteList: list
        });
      }
      that.data.page++;
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function onLoad(options) {
    var that = this;
    that.fetchRecords();
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function onReady() {},
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function onShow() {},
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function onHide() {},
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function onUnload() {},
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function onPullDownRefresh() {},
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function onReachBottom() {
    var that = this;
    that.loadMore();
    //设置定时器，消失
    setTimeout(function () {
      that.setData({
        dataMore: false,
        noMore: false
      });
    }, 1000);
    clearTimeout();
  }
});