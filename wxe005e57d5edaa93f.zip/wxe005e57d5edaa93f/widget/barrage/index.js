Component({
  // 样式隔离
  options: {
    styleIsolation: "isolated"
  },
  properties: {
    // 滚动展示几行
    row: {
      type: Number,
      value: 3
    },
    // 展示数据
    bullet: {
      type: Array,
      required: true
    },
    // 时长 (s)
    duration: {
      type: Number,
      value: 25
    }
  },
  data: {
    wrapperData: [],
    context: ""
  },
  lifetimes: {
    attached: function attached() {
      var root = this.formatData(this.data.row);
      var wrapperData = root.map(function (item, index) {
        var wrapper = {};
        var rowData = {
          list: item
        };
        wrapper["wrapper"] = [rowData, rowData, rowData];
        return wrapper;
      });
      this.setData({
        wrapperData: wrapperData
      });
      this.wrapperScroll();
    }
  },
  methods: {
    wrapperScroll: function wrapperScroll() {
      var _this = this;
      var query = wx.createSelectorQuery().in(this);
      //获取盒子的宽度
      query.select(".barrage-row-item").boundingClientRect(function (rect) {
        // console.log(rect);
        //进行动画
        _this.animate(".barrage-scroll", [{
          translateX: "0"
        }, {
          translateX: "-".concat(rect.right * 2, "px")
        }], _this.data.duration * 2 * 1000, function () {
          _this.clearAnimation(".barrage-scroll", function () {
            _this.wrapperScroll();
          });
        });
      }).exec();
    },
    formatData: function formatData(cnt) {
      var _this2 = this;
      var data = new Array(cnt).fill();
      var res = data.map(function (item, index) {
        return _this2.shuffle(_this2.data.bullet);
      });
      return res;
    },
    shuffle: function shuffle(data) {
      var arr = new Array(data).flat();
      for (var i = 1; i < arr.length; i++) {
        var random = Math.floor(Math.random() * (i + 1));
        var _ref = [arr[random], arr[i]];
        arr[i] = _ref[0];
        arr[random] = _ref[1];
      }
      return arr;
    },
    handleBarrage: function handleBarrage(e) {
      var dataset = e.currentTarget.dataset;
      var wrapperData = this.data.wrapperData;
      this.setData({
        context: wrapperData[dataset.wrapperindex].wrapper[dataset.itemsindex].list[dataset.listindex]
      });
      this.triggerEvent("componentContext", this.data.context);
    }
  }
});