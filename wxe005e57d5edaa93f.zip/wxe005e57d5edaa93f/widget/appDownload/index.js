Component({
  options: {
    multipleSlots: true // 在组件定义时的选项中启用多slot支持
  },

  properties: {},
  data: {
    windowHeight: 0,
    windowWidth: 0,
    isShow: false
  },
  created: function created() {},
  attached: function attached() {
    var that = this;
    wx.getSystemInfo({
      success: function success(res) {
        that.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        });
      }
    });
  },
  methods: {
    catchtapFn: function catchtapFn() {
      return null;
    },
    closePopup: function closePopup() {
      this.setData({
        isShow: false
      });
      this.triggerEvent('showTextarea', true);
    },
    showPopup: function showPopup() {
      this.setData({
        isShow: true
      });
    }
  }
});