var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var api = require("./../../utils/api.js");var config = require("./../../config.js");var app = getApp();Component({
  options: {
    multipleSlots: true // 在组件定义时的选项中启用多slot支持
  },

  properties: {
    tag: {
      type: String,
      required: true
    }
  },
  data: {
    windowHeight: 0,
    windowWidth: 0,
    showPrompt: false,
    couponNum: 0,
    couponId: "",
    isIos: false,
    isCanPay: false,
    redirectConfig: {},
    templateIds: [],
    questionText: "",
    dialogHeight: 594
  },
  created: function created() {
    // this.initData();
  },
  attached: function attached() {
    var _this = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
      var that, redirectConfigArr;
      return _regeneratorRuntime2().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            that = _this;
            wx.getSystemInfo({
              success: function success(res) {
                _this.setData({
                  isIos: res.system.indexOf("iOS") > -1
                });
              }
            });
            if (that.data.isIos) {
              that.setData({
                dialogHeight: 688
              });
            }
            _context.next = 5;
            return app.fetchRedirectConfig({
              position: "pay"
            });
          case 5:
            redirectConfigArr = _context.sent;
            if (redirectConfigArr.length > 0) {
              _this.setData({
                redirectConfig: redirectConfigArr[0]
              });
            }
          case 7:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }))();
  },
  methods: {
    initData: function initData() {
      this.fetchCouponNum();
      this.isCanPayFn();
      this.fetchTemplateIds();
    },
    setQuestionText: function setQuestionText(questionText) {
      this.setData({
        questionText: questionText
      });
    },
    showDialog: function showDialog() {
      this.setData({
        showPrompt: true
      });
    },
    closeDialog: function closeDialog() {
      this.triggerEvent("hideDialog");
      this.setData({
        showPrompt: false
      });
    },
    fetchCouponNum: function fetchCouponNum() {
      console.log('fetchCouponNum--->');
      var that = this;
      api.fetchGet(api.baseUrl + "ask/coupon/count", {}).then(function (res) {
        that.setData({
          couponNum: res.coupon_count,
          couponId: res.coupon_id
        });
      });
    },
    fetchTemplateIds: function fetchTemplateIds() {
      var that = this;
      api.fetchGet(api.baseUrl + "wxapp/templateIds", {
        business: "invite_credit_notification"
      }).then(function (res) {
        that.setData({
          templateIds: res.templateIds
        });
      });
    },
    isCanPayFn: function isCanPayFn() {
      var that = this;
      var url = api.baseUrl + "store/weapp/share";
      api.fetchGet(url, {
        noTip: true
      }).then(function (res) {
        that.setData({
          isCanPay: res.showTimeLine
        });
      });
    },
    platformPay: function platformPay() {
      ///塔罗占星
      //ios不支持支付
      if (this.data.isIos) {
        return wx.showModal({
          content: "您的账号上没有可使用的免费提问券，小程序中暂不支持付费提问，如需付费提问请下载问问APP。",
          confirmColor: "#F44236",
          confirmText: "去下载",
          success: function success(res) {
            if (res.confirm) {
              wx.navigateTo({
                url: "../../pages/leadDownload/index"
              });
            } else if (res.cancel) {
              console.log('用户点击取消');
            }
          }
        });
      } else {
        //安卓开审核模式，未开启不支持支付，开启后支持支付
        if (!this.data.isCanPay) {
          return wx.showModal({
            content: "您的账号上没有可使用的免费提问券，小程序中暂不支持付费提问，如需付费提问请下载问问APP。",
            confirmColor: "#F44236",
            confirmText: "去下载",
            success: function success(res) {
              if (res.confirm) {
                wx.navigateTo({
                  url: "../../pages/leadDownload/index"
                });
              } else if (res.cancel) {
                console.log('用户点击取消');
              }
            }
          });
        } else {
          // 展示 支付 弹窗
          this.triggerEvent("pay");
          // return this.jumpMiniProgram();
        }
      }
      ////塔罗牌无限次情感问答 [取消支付] 2022/10/26的版本
      // this.setData({
      //   showPrompt: false,
      // });
      // return wx.showModal({
      //   content: "您的账号上没有可使用的免费提问券，小程序中暂不支持付费提问，如需付费提问请下载问问APP。",
      //   confirmColor: "#F44236",
      //   confirmText:"去下载",
      //   success(res){
      //     if(res.confirm){
      //       wx.navigateTo({
      //         url:"../../pages/leadDownload/index"
      //       })
      //     }else if (res.cancel) {
      //       console.log('用户点击取消')
      //     }
      //   }
      // });
    },
    useCouponPay: function useCouponPay() {
      console.log("coupon_id -------->> " + this.data.couponId);
      this.triggerEvent("couponPay", this.data.couponId);
    },
    jumpMiniProgram: function jumpMiniProgram() {
      var redirectConfig = this.data.redirectConfig;
      wx.navigateToMiniProgram({
        appId: redirectConfig.wxAppId,
        path: redirectConfig.path ? redirectConfig.path : "pages/index/index",
        extraData: {},
        envVersion: "trial"
      });
    },
    jumpCouponRedemption: function jumpCouponRedemption() {
      var tag = this.data.tag;
      if (tag === "tarot") {
        wx.setStorageSync("questionText", this.data.questionText);
      } else {
        wx.setStorageSync("dice_questionText", this.data.questionText);
      }
      app.applySubMsg(this.data.templateIds, app.globalData.userInfo.uid, function () {
        wx.showToast({
          title: tag === "tarot" ? "待解答问题已保存，获取提问券后，点击“免费问塔罗”即可获得解答" : "待解答问题已保存，获取提问券后，点击“占星骰子”即可获得解答",
          icon: "none",
          duration: 2000
        });
        setTimeout(function () {
          wx.redirectTo({
            url: "../couponRedemption/index"
          });
        }, 2200);
      });
    },
    //ios情况下也可以选择钱包支付
    walletPay: function walletPay() {
      console.log('2222');
      // 展示 支付 弹窗
      this.triggerEvent("pay");
    }
  }
});