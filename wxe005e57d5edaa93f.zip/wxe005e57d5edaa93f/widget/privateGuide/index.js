Component({
  data: {
    showPrivacy: false,
    hasRefuse: false
  },
  created: function created() {},
  attached: function attached() {
    var that = this;
    wx.getPrivacySetting({
      success: function success(res) {
        if (res.needAuthorization) {
          that.setData({
            showPrivacy: true
          });
        }
      },
      fail: function fail() {},
      complete: function complete() {}
    });
  },
  methods: {
    handleOpenPrivacyContract: function handleOpenPrivacyContract() {
      wx.openPrivacyContract({
        success: function success(res) {},
        // 打开成功
        fail: function fail() {},
        // 打开失败
        complete: function complete() {}
      });
    },
    handleAgreePrivacyAuthorization: function handleAgreePrivacyAuthorization() {
      this.setData({
        showPrivacy: false
      });
      this.triggerEvent('agree');
    },
    handleRefuse: function handleRefuse() {
      console.log('refuse');
      if (this.data.hasRefuse) {
        wx.showToast({
          title: '很抱歉无法为你继续提供服务，您可以手动退出！',
          icon: 'none',
          duration: 3000,
          mask: true
        });
        return;
      }
      this.setData({
        hasRefuse: true
      });
    },
    handleToLink: function handleToLink(e) {
      var idx = e.currentTarget.dataset.idx;
      wx.navigateTo({
        url: "../../pages/webView/index?idx=" + idx
      });
    },
    catchTouchMove: function catchTouchMove() {
      return false;
    }
  }
});