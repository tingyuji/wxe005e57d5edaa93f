Component({
  /**
   * 组件的属性列表
   */
  properties: {
    avatar: {
      type: String
    },
    nickName: {
      type: String
    }
  },
  /**
   * 组件的初始数据
   */
  data: {
    showDialog: false,
    windowHeight: "",
    windowWidth: ""
  },
  attached: function attached() {
    var res = wx.getSystemInfoSync();
    this.setData({
      windowHeight: res.windowHeight,
      windowWidth: res.windowWidth
    });
  },
  /**
   * 组件的方法列表
   */
  methods: {
    close: function close() {
      this.setData({
        showDialog: false
      });
    },
    open: function open() {
      this.setData({
        showDialog: true
      });
    },
    handleToDownLoad: function handleToDownLoad() {
      wx.navigateTo({
        url: '../leadDownload/index'
      });
    }
  }
});