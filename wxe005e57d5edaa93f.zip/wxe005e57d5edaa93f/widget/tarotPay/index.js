var _regeneratorRuntime2 = require("../../@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("../../@babel/runtime/helpers/asyncToGenerator");var api = require("./../../utils/api.js");var config = require("./../../config.js");var app = getApp();var canSubmit = true;Component({
  options: {
    multipleSlots: true // 在组件定义时的选项中启用多slot支持
  },

  properties: {
    // 提问题目， 外部传
    questionText: {
      type: String,
      required: true
    },
    payPriceType: {
      type: String,
      default: "tarot"
    }
  },
  data: {
    windowHeight: 0,
    windowWidth: 0,
    showTarotPay: false,
    // 展示价格 box
    showPayBox: true,
    // 验证码 box
    showCodeBox: false,
    // 钱包余额
    balance: 0,
    // 选择支付方式
    showPayConfigBox: true,
    // 支付方式
    payConfigArr: [{
      icon: "https://brup.shengri.cn/goods/2019/11/14111428_8889322b0afc4b8698d2b3ccd85c309a.jpg",
      name: "微信支付",
      payType: 10
    }, {
      icon: "https://brup.shengri.cn/goods/2017/07/FotSXy4BdkO3aGlZcWC85wYXxmaG.png",
      name: "钱包支付",
      payType: 28
    }],
    // 支付价格列表
    pricesList: [],
    // 默认价格
    choosePrice: "",
    postId: "",
    orderId: "",
    codeDesc: "再发一次",
    // 验证码
    code: "",
    ticketCode: "",
    payParams: {},
    isIos: false,
    //用于判断ios下钱包支付
    //支付失败
    height: "",
    hasShow: false
  },
  created: function created() {},
  attached: function attached() {
    var _this = this;
    var that = this;
    // this.initData();
    wx.getSystemInfo({
      success: function success(res) {
        that.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth,
          height: res.windowHeight - 261
        });
      }
    });
    wx.getSystemInfo({
      success: function success(res) {
        _this.setData({
          isIos: res.system.indexOf("iOS") > -1
        });
      }
    });
    console.log("isIos", that.data.isIos);
  },
  methods: {
    initData: function initData() {
      // this.fetchPayConfig();
      this.fetchPriceList();
      this.fetchWallet();
    },
    showPay: function showPay() {
      this.setData({
        showTarotPay: true,
        showPayBox: true
      });
    },
    hidePayBox: function hidePayBox() {
      this.setData({
        showTarotPay: false
      });
    },
    // 支付方式
    fetchPayConfig: function fetchPayConfig() {
      var _this2 = this;
      return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
        var that, data;
        return _regeneratorRuntime2().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              that = _this2;
              _context.next = 3;
              return api.fetchPost("".concat(api.baseUrl, "payment/billingConfig"), {
                src: "ask"
              });
            case 3:
              data = _context.sent;
              _this2.setData({
                payConfigArr: data.items
              });
            case 5:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }))();
    },
    setPayParams: function setPayParams(params) {
      this.setData({
        payParams: params
      });
    },
    // 获取钱包余额
    fetchWallet: function fetchWallet() {
      var that = this;
      api.fetchGet(api.baseUrl + "store/wallet").then(function (res) {
        that.setData({
          balance: res.userBalance
        });
      });
    },
    // 提问价格
    fetchPriceList: function fetchPriceList() {
      var that = this;
      var showPayConfigBox = this.data.showPayConfigBox;
      api.fetchPost(api.baseUrl + "ask/posts_price", {
        type: that.data.payPriceType
      }).then(function (res) {
        console.log(res);
        var prices = res.prices;
        var choosePrice = prices.find(function (item) {
          return item.is_default === 1;
        }).price;
        prices.forEach(function (v, k) {
          if (v.coupon_id && v.is_default) {
            showPayConfigBox = false;
          }
        });
        that.setData({
          pricesList: prices,
          choosePrice: choosePrice,
          showPayConfigBox: showPayConfigBox
        });
      });
    },
    // 选择价格
    choosePriceFn: function choosePriceFn(e) {
      var that = this;
      var index = e.currentTarget.dataset.index;
      var pricesList = that.data.pricesList;
      var params = this.data.payParams;
      pricesList.forEach(function (v, k) {
        if (index == k) {
          pricesList[k].is_default = 1;
        } else {
          pricesList[k].is_default = 0;
        }
      });
      params.price = pricesList.find(function (item) {
        return item.is_default === 1;
      }).price;
      that.setData({
        pricesList: pricesList,
        payParams: params,
        showPayConfigBox: pricesList[index].coupon_id ? false : true,
        choosePrice: params.price
      });
    },
    // 选择支付方式
    choosePayFn: function choosePayFn(e) {
      var that = this;
      var pay_channel = e.currentTarget.dataset.type;
      var params = this.data.payParams;
      var pricesList = this.data.pricesList;
      wx.showToast({
        title: "支付中...",
        icon: "loading",
        duration: 10000
      });
      if (!params.price) {
        params.price = pricesList.find(function (item) {
          return item.is_default === 1;
        }).price;
      }
      // 不同支付
      if (pay_channel == 10) {
        this.wxPay(pay_channel, params);
      } else if (pay_channel == 28) {
        this.octinnWalletPay(pay_channel, params);
      } else if (pay_channel == 1) {
        that.useCouponPay();
      }
    },
    // 使用提问券支付
    useCouponPay: function useCouponPay() {
      var coupon_id = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this.data.pricesList[0].coupon_id;
      var inviteUserId = arguments.length > 1 ? arguments[1] : undefined;
      var that = this;
      var params = this.data.payParams;
      params.coupon_id = coupon_id;
      if (!params.price) {
        params.price = this.data.pricesList[0].price;
      }
      if (inviteUserId) {
        params.invite_user_id = inviteUserId;
      }
      api.fetchPost(api.baseUrl + "ask/posts", params).then(function (res) {
        wx.hideToast();
        if (!res.status) {
          that.setData({
            postId: res.post_id
          });
          // 支付成功进如提问详情页面
          wx.redirectTo({
            url: "../detail/index?fetchConsumeCnt=true&postId=" + that.data.postId
          });
        }
      }).catch(function (err) {
        canSubmit = true;
      });
    },
    // 微信支付
    wxPay: function wxPay(pay_channel, params) {
      return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
        var _yield$api$fetchPost, status, order_id, post_id, pay_data;
        return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return api.fetchPost(api.baseUrl + "ask/posts", params);
            case 2:
              _yield$api$fetchPost = _context2.sent;
              status = _yield$api$fetchPost.status;
              order_id = _yield$api$fetchPost.order_id;
              post_id = _yield$api$fetchPost.post_id;
              if (!status) {
                _context2.next = 8;
                break;
              }
              return _context2.abrupt("return");
            case 8:
              _context2.next = 10;
              return api.fetchPost(api.baseUrl + "payment/billingPay", {
                order_id: order_id,
                pay_channel: pay_channel,
                openid: wx.getStorageSync("openId")
              });
            case 10:
              pay_data = _context2.sent;
              wx.hideToast();
              wx.requestPayment({
                timeStamp: pay_data.timestamp + "",
                nonceStr: pay_data.nonceStr,
                package: pay_data.package,
                signType: pay_data.signType,
                paySign: pay_data.paySign,
                success: function success(res) {
                  // console.log('支付成功。。。。进入提问详情页面');
                  // 支付成功进如提问详情页面
                  wx.redirectTo({
                    url: "/pages/detail/index?fetchConsumeCnt=true&postId=" + post_id
                  });
                },
                fail: function fail(res) {
                  wx.showModal({
                    title: "提示",
                    content: "支付失败~",
                    confirmColor: "#F44236",
                    showCancel: false
                  });
                }
              });
            case 13:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }))();
    },
    // 钱包支付
    octinnWalletPay: function octinnWalletPay(pay_channel, params) {
      var _this3 = this;
      return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee3() {
        var that, _yield$api$fetchPost2, status, order_id, post_id;
        return _regeneratorRuntime2().wrap(function _callee3$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
              that = _this3;
              if (!(_this3.data.balance < params.price)) {
                _context3.next = 4;
                break;
              }
              wx.hideToast();
              // return wx.showToast({
              //   title: "钱包余额不足...",
              //   icon: "none",
              //   duration: 2000,
              // });
              return _context3.abrupt("return", that.setData({
                showPayBox: false,
                hasShow: true
              }));
            case 4:
              _context3.next = 6;
              return api.fetchPost(api.baseUrl + "ask/posts", params);
            case 6:
              _yield$api$fetchPost2 = _context3.sent;
              status = _yield$api$fetchPost2.status;
              order_id = _yield$api$fetchPost2.order_id;
              post_id = _yield$api$fetchPost2.post_id;
              wx.hideToast();
              if (!status) {
                that.sendCode();
                that.setData({
                  showPayBox: false,
                  showCodeBox: true,
                  postId: post_id,
                  orderId: order_id
                });
              }
            case 12:
            case "end":
              return _context3.stop();
          }
        }, _callee3);
      }))();
    },
    //发送验证码
    sendCode: function sendCode() {
      var that = this;
      var data = {
        phone: app.getUserPhone(),
        type: 5,
        noTip: true
      };
      api.fetchPost(api.baseUrl + "account/send_verify_code", data).then(function (resp) {
        that.setData({
          ticketCode: resp.ticket
        });
        that.settime(60);
      }).catch(function (err) {
        wx.showModal({
          title: "提示",
          content: err.data.msg,
          confirmColor: "#cc9e3d",
          showCancel: false,
          success: function success(res) {}
        });
      });
    },
    // 倒计时
    settime: function settime(val) {
      var that = this;
      if (val <= 0) {
        var value = "再发一次";
        this.setData({
          codeDesc: value
        });
      } else {
        val = val - 1;
        this.setData({
          codeDesc: val + "s"
        });
        setTimeout(function () {
          that.settime(val);
        }, 1000);
      }
    },
    // 输入验证码
    inputCode: function inputCode(e) {
      this.setData({
        code: e.detail.value
      });
    },
    // 关闭输入验证码弹框
    showCodeBoxFn: function showCodeBoxFn() {
      this.setData({
        showCodeBox: false,
        showPayBox: true,
        showTarotPay: false
      });
      canSubmit = true;
    },
    // 再发一次
    againSend: function againSend() {
      var that = this;
      if (that.data.codeDesc == "再发一次") {
        that.sendCode();
        that.settime(60);
      }
    },
    // 确认钱包付款
    onClockPay: function onClockPay() {
      var that = this;
      var code = that.data.code;
      if (code.length < 4) {
        return wx.showModal({
          title: "提示",
          content: "请输入正确验证码",
          confirmColor: "#cc9e3d",
          showCancel: false,
          success: function success(res) {}
        });
      }
      wx.showToast({
        title: "支付中",
        icon: "loading",
        duration: 10000
      });
      api.fetchPost(api.baseUrl + "payment/wallet", {
        order_id: that.data.orderId,
        // pay_channel: 28,
        code: that.data.code,
        ticket: that.data.ticketCode
      }).then(function (resp) {
        wx.hideToast();
        if (resp.result == "success") {
          // 支付成功进如提问详情页面
          wx.redirectTo({
            url: "/pages/detail/index?fetchConsumeCnt=true&postId=" + that.data.postId
          });
        } else {
          wx.showModal({
            title: "提示",
            content: "请输入正确的验证码",
            confirmColor: "#cc9e3d",
            showCancel: false,
            success: function success(res) {}
          });
        }
      }).catch(function (err) {
        wx.hideToast();
      });
    },
    // 自定义赏金暂未开放
    customFn: function customFn() {
      wx.showToast({
        title: "敬请期待",
        icon: "none",
        duration: 800
      });
    },
    noClose: function noClose() {
      return;
    },
    close: function close() {
      this.setData({
        hasShow: false,
        showTarotPay: false
      });
    },
    open: function open() {
      this.setData({
        hasShow: true
      });
    }
  }
});