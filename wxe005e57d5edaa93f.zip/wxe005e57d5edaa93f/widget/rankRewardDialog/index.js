var api = require("./../../utils/api.js");Component({
  /**
   * 组件的属性列表
   */
  properties: {
    isShow: {
      type: Boolean,
      value: true
    }
  },
  /**
   * 组件的初始数据
   */
  data: {
    windowHeight: "",
    windowWidth: "",
    show: false,
    activityContent: []
  },
  attached: function attached() {
    var res = wx.getSystemInfoSync();
    this.setData({
      windowHeight: res.windowHeight,
      windowWidth: res.windowWidth
    });
    this.getActivityContent();
  },
  /**
   * 组件的方法列表
   */
  methods: {
    close: function close() {
      this.setData({
        show: false
      });
    },
    open: function open() {
      this.setData({
        show: true
      });
    },
    getActivityContent: function getActivityContent() {
      var that = this;
      api.fetchGet(api.baseUrl + "entrance/productentrance?alias=mini_activity_content", {}).then(function (res) {
        if (res.tabs.length === 0) {
          that.setData({
            isShow: false
          });
        } else {
          var items = res.tabs;
          items.forEach(function (v, k) {
            items[k].content = items[k].content.split("\n");
            items[k].content.forEach(function (v, j) {
              items[k].content[j] = items[k].content[j].replace(/\\n/g, "\n");
            });
          });
          console.log(items);
          that.setData({
            activityContent: items,
            isShow: true
          });
        }
        that.triggerEvent("handleShow", that.data.isShow);
        // console.log("isshow", that.data.isShow);
      });
    },
    handleJoin: function handleJoin() {
      var url = this.data.activityContent[0].uri;
      var intentString = this.getQueryVariable(url, "intent");
      var _JSON$parse = JSON.parse(decodeURIComponent(intentString)),
        path = _JSON$parse.path;
      wx.navigateTo({
        url: "/".concat(path)
      });
    },
    getQueryVariable: function getQueryVariable(uri, variable) {
      var paramsString = uri.split("?")[1];
      var vars = paramsString.split("&");
      for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        if (pair[0] == variable) {
          return pair[1];
        }
      }
      return false;
    }
  }
});