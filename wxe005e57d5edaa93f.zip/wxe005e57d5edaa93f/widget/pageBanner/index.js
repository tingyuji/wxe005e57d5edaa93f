var api = require("./../../utils/api.js");Component({
  options: {
    multipleSlots: true // 在组件定义时的选项中启用多slot支持
  },

  properties: {
    bannerAlias: {
      type: String
    }
  },
  data: {
    bannerList: [],
    current: 0
  },
  created: function created() {},
  attached: function attached() {
    this.fetchBanner();
  },
  methods: {
    fetchBanner: function fetchBanner() {
      var that = this;
      api.fetchGet(api.baseUrl + "entrance/productentrance?alias=" + that.data.bannerAlias, {}).then(function (res) {
        that.setData({
          bannerList: res.tabs
        });
        console.log("banner", that.data.bannerList);
      });
    },
    //获取current
    swiperCurrentchange: function swiperCurrentchange(e) {
      // console.log("e", e);
      var _e$detail = e.detail,
        current = _e$detail.current,
        source = _e$detail.source;
      if (source === "autoplay" || source === "touch") {
        this.setData({
          current: current
        });
      }
    },
    doAction: function doAction(e) {
      var uri = e.currentTarget.dataset.uri;
      var intentString = this.getQueryVariable(uri, "intent");
      var _JSON$parse = JSON.parse(decodeURIComponent(intentString)),
        userName = _JSON$parse.userName,
        path = _JSON$parse.path;
      if (userName === "mini_local") {
        return wx.navigateTo({
          url: "/".concat(path)
        });
      }
      wx.navigateToMiniProgram({
        appId: userName,
        path: path,
        extraData: {},
        envVersion: "trial"
      });
    },
    getQueryVariable: function getQueryVariable(uri, variable) {
      var paramsString = uri.split("?")[1];
      var vars = paramsString.split("&");
      for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        if (pair[0] == variable) {
          return pair[1];
        }
      }
      return false;
    },
    submitFormid1: function submitFormid1() {
      var url = "";
      if (wx.getStorageSync("questionText")) {
        url = "../tarotGamePay/index";
      } else {
        url = "../tarotGame/index";
      }
      wx.navigateTo({
        url: url
      });
    }
  }
});