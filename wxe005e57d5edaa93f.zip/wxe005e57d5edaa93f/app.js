var _regeneratorRuntime2 = require("@babel/runtime/helpers/regeneratorRuntime");var _asyncToGenerator2 = require("@babel/runtime/helpers/asyncToGenerator");require("@babel/runtime/helpers/Arrayincludes");var api = require("/utils/api.js");var config = require("config.js");App({
  onLaunch: function onLaunch() {
    var that = this;
    //调用API从本地缓存中获取数据
    var userInfo = wx.getStorageSync("userInfo");
    var wxInfo = wx.getStorageSync("wxInfo");
    var openId = wx.getStorageSync("openId");
    var channel = wx.getStorageSync("channel");
    var wxAppSession = wx.getStorageSync("wxAppSession");
    if (openId) {
      that.setAllow(1);
    }
    if (openId) {
      api.setUdid(openId);
    }
    if (channel) {
      api.setChannel(channel);
    }
    if (userInfo) {
      //登录态未过期
      that.globalData.userInfo = userInfo;
      that.globalData.tok = userInfo.tok;
      api.setToken(userInfo.tok);
    }
    if (wxInfo) {
      that.globalData.wxInfo = wxInfo;
      api.setUdid(wxInfo.openId);
    }
    if (wxAppSession) {
      api.setSession(wxAppSession);
    }
    wx.setInnerAudioOption({
      obeyMuteSwitch: false
    });
  },
  onShow: function onShow(options) {
    var that = this;
    var userInfo = wx.getStorageSync("userInfo");
    /**
     * 进入小程序不再主动用户授权获取wxInfo(微信机制改变，不允许主动调用wx.getUserInfo)
     * 当本地有userInfo数据时，说明之前已经授权并登录过，此时只要检查session_key是否过期，
     * 如果过期重新微信登录，此时可以不用button组件调用wx.getUserInfo来获取用户数据，
     * 直接调用即可
     */
    // if (userInfo) {
    //   wx.checkSession({
    //     success: function () {},
    //     fail: function () {
    //       that.getUserInfo();
    //     },
    //   });
    // }
    // options.referrerInfo.extraData = {
    //   id: 12390002
    // }
    var scenceList = [1007, 1008, 1005, 1006, 1027, 1042, 1106, 1155, 1150, 1012, 1048, 1053];
    if (scenceList.includes(options.scene)) {
      api.setChannel("".concat(config.octinnId).concat(options.scene));
    }
    if (options.referrerInfo.extraData) {
      that.globalData.channelID = options.referrerInfo.extraData.id;
      api.setChannel(options.referrerInfo.extraData.id);
    }
  },
  // 退出登录
  logout: function logout() {
    try {
      wx.clearStorageSync();
      api.setToken("");
    } catch (e) {
      // Do something when catch error
    }
    this.globalData.userInfo = null;
  },
  checkLoginStatus: function checkLoginStatus() {
    // 如果没有登录，就去登录授权
    if (wx.getSystemInfoSync().isQB) {
      if (!app.globalData.userInfo) {
        wx.navigateTo({
          url: "../login/login"
        });
      }
    } else {
      if (!this.isLogin()) {
        if (this.getAllow()) {
          wx.navigateTo({
            url: "../login/login"
          });
        } else {
          wx.navigateTo({
            url: "../authorization/authorization"
          });
        }
        return;
      }
    }
    return true;
  },
  setChannel: function setChannel(channel) {
    api.setChannel(channel);
    wx.setStorageSync("channel", channel);
  },
  setUdid: function setUdid(openId) {
    api.setUdid(openId);
    wx.setStorageSync("openId", openId);
  },
  // 定位当前城市

  // 判断是否登录
  isLogin: function isLogin() {
    var userInfo = wx.getStorageSync("userInfo") || {
      tok: ""
    };
    if (userInfo.tok) {
      return true;
    } else {
      return false;
    }
  },
  // 保存用户信息
  setUserInfo: function setUserInfo(userInfo) {
    wx.setStorageSync("userInfo", userInfo);
    this.globalData.userInfo = userInfo;
  },
  // 获取用户的OpenId
  getUserWxOpenId: function getUserWxOpenId() {
    return this.globalData.wxInfo.openId;
  },
  getUserPhone: function getUserPhone() {
    return this.globalData.userInfo.phone;
  },
  currentUser: function currentUser(cb) {
    var that = this;
    var userInfo = that.globalData.wxInfo;
    if (userInfo) {
      typeof cb == "function" && cb(userInfo);
    }
  },
  getUserInfo: function getUserInfo(cb, extra) {
    wx.showToast({
      title: "加载中...",
      icon: "loading",
      duration: 5000
    });
    var that = this;
    try {
      var wxInfo = wx.getStorageSync("wxInfo");
      if (wxInfo) {
        that.globalData.wxInfo = wxInfo;
      }
      var loginCode = wx.getStorageSync("loginCode");
      wx.getUserProfile({
        desc: "用于完善会员资料",
        // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
        success: function success(res) {
          that.setAllow(1);
          var data = {
            code: loginCode,
            encrypted_data: res.encryptedData,
            iv: res.iv
          };
          var apiUrl = api.baseUrl + "account/code_login";
          api.fetchPost(apiUrl, data).then(function (resp) {
            wx.hideToast();
            if ("wxAppSession" in resp) {
              api.setSession(resp.wxAppSession);
              wx.setStorageSync("wxAppSession", resp.wxAppSession);
            }
            if ("wxInfo" in resp) {
              wx.setStorageSync("wxInfo", resp.wxInfo);
              wx.setStorageSync("openId", resp.wxInfo.openId);
              that.globalData.wxInfo = resp.wxInfo;
              that.setUdid(resp.wxInfo.openId);
            }
            if ("userInfo" in resp) {
              wx.setStorageSync("userInfo", resp.userInfo);
              that.globalData.userInfo = resp.userInfo;
              api.setToken(resp.userInfo.tok);
              typeof cb == "function" && cb(that.globalData.userInfo);
            } else if ("wxInfo" in resp) {
              typeof cb == "function" && cb(resp.wxInfo);
            }
          }).catch(function (error) {
            typeof cb == "function" && cb(res);
          });
        },
        fail: function fail(re) {
          that.setAllow(0);
          wx.hideToast();
        }
      });

      // wx.login({
      //   success: function (de) {
      //     console.log("de", de);
      //     wx.getUserProfile({
      //       desc: "用于完善会员资料", // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      //       success: function (res) {
      //         console.log("res", res);
      //         that.globalData.isAllow = 1;
      //         wx.setStorageSync("isAllow", that.globalData.isAllow);
      //         let data = {
      //           code: de.code,
      //           encrypted_data: res.encryptedData,
      //           iv: res.iv,
      //         };

      //         let apiUrl = api.baseUrl + "account/code_login";
      //         api
      //           .fetchPost(apiUrl, data)
      //           .then((resp) => {
      //             wx.hideToast();
      //             if ("wxAppSession" in resp) {
      //               api.setSession(resp.wxAppSession);
      //               wx.setStorageSync("wxAppSession", resp.wxAppSession);
      //             }
      //             if ("wxInfo" in resp) {
      //               wx.setStorageSync("wxInfo", resp.wxInfo);
      //               wx.setStorageSync("openId", resp.wxInfo.openId);
      //               that.globalData.wxInfo = resp.wxInfo;
      //               that.setUdid(resp.wxInfo.openId);
      //               // 上传用户的openid和unionid
      //             }
      //             if ("userInfo" in resp) {
      //               wx.setStorageSync("userInfo", resp.userInfo);
      //               that.globalData.userInfo = resp.userInfo;
      //               api.setToken(resp.userInfo.tok);
      //               typeof cb == "function" && cb(that.globalData.userInfo);
      //             } else if ("wxInfo" in resp) {
      //               typeof cb == "function" && cb(resp.wxInfo);
      //             }
      //           })
      //           .catch((error) => {
      //             typeof cb == "function" && cb(res);
      //           });
      //       },
      //       fail: function (re) {
      //         console.log("re", re);
      //         that.globalData.isAllow = 0;
      //         wx.setStorageSync("isAllow", that.globalData.isAllow);
      //         wx.hideToast();
      //       },
      //     });
      //   },
      // });
    } catch (e) {}
  },
  // 获取授权状态
  getAllow: function getAllow() {
    if (wx.getStorageSync("isAllow")) {
      return true;
    } else {
      return false;
    }
  },
  //判断是否授权/登录，返回boolean
  loginStatus: function loginStatus() {
    var hasLogin = this.isLogin();
    var hasAllow = this.getAllow();
    var status = hasLogin && hasAllow;
    return status;
  },
  // 存储授权状态
  setAllow: function setAllow(flag) {
    this.globalData.isAllow = flag;
    wx.setStorageSync("isAllow", flag);
  },
  // 获取小程序跳转参数
  fetchRedirectConfig: function fetchRedirectConfig(params) {
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee() {
      var data;
      return _regeneratorRuntime2().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return api.fetchGet(api.baseUrl + "store/weapp/redirect", params);
          case 2:
            data = _context.sent;
            return _context.abrupt("return", data);
          case 4:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }))();
  },
  // 申请订阅
  applySubMsg: function applySubMsg(templateIds, business_id, cb) {
    var _this = this;
    return _asyncToGenerator2( /*#__PURE__*/_regeneratorRuntime2().mark(function _callee2() {
      var subMsgData, accept_template_ids, saveData;
      return _regeneratorRuntime2().wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            if (!(templateIds.length <= 0)) {
              _context2.next = 2;
              break;
            }
            return _context2.abrupt("return", cb && cb());
          case 2:
            if (wx.requestSubscribeMessage) {
              _context2.next = 4;
              break;
            }
            return _context2.abrupt("return", cb && cb());
          case 4:
            _context2.prev = 4;
            _context2.next = 7;
            return _this.requestSubMsg(templateIds);
          case 7:
            subMsgData = _context2.sent;
            console.log(subMsgData);
            // 用户允许订阅模板列表
            accept_template_ids = templateIds.filter(function (item) {
              return subMsgData[item] === "accept";
            });
            if (!(accept_template_ids.length > 0)) {
              _context2.next = 18;
              break;
            }
            _context2.next = 13;
            return api.fetchPost(api.baseUrl + "wxapp/saveSubscribedata", {
              open_id: wx.getStorageSync("openId"),
              template_ids: accept_template_ids,
              business_id: business_id
            });
          case 13:
            saveData = _context2.sent;
            if (saveData.status === 0) {
              wx.showToast({
                title: "订阅成功",
                icon: "success",
                duration: 1500
              });
            }
            cb && cb();
            _context2.next = 19;
            break;
          case 18:
            cb && cb();
          case 19:
            _context2.next = 25;
            break;
          case 21:
            _context2.prev = 21;
            _context2.t0 = _context2["catch"](4);
            cb && cb();
            console.log(_context2.t0);
          case 25:
          case "end":
            return _context2.stop();
        }
      }, _callee2, null, [[4, 21]]);
    }))();
  },
  // 向用户申请订阅
  requestSubMsg: function requestSubMsg(templateIds) {
    return new Promise(function (resolve, reject) {
      wx.requestSubscribeMessage({
        tmplIds: templateIds,
        success: function success(res) {
          resolve(res);
        },
        fail: function fail(err) {
          reject(err);
        }
      });
    });
  },
  formatTime: function formatTime() {
    var date = new Date();
    var year = date.getFullYear();
    var month = date.getMonth() + 1 < 10 ? "0".concat(date.getMonth() + 1) : date.getMonth() + 1;
    var day = date.getDate();
    return "".concat(year).concat(month).concat(day);
  },
  globalData: {
    channelID: null,
    // 渠道ID
    isAllow: 0,
    // 判断是否授权
    userInfo: null,
    tok: "",
    cityId: 110100,
    city: "北京市",
    wxInfo: null
  }
});