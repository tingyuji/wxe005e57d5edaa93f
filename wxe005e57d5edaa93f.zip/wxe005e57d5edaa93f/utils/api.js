var app;setTimeout(function () {
  app = getApp();
});var md5 = require("md5.min");var config = require("../config.js");console.log(config.name + "!!!!!!!!!!!!!!!!!!!!!!!   <------  注意");console.log(config.appId + "!!!!!!!!!!!!!!!!!!!!!!!   <------  注意appId");var HOST = "https://api.tttarot.com/";var HEADER = {
  "Content-Type": "application/json",
  "OI-APPKEY": config.appKey,
  "OI-UDID": "00000000000000000000000000000000",
  "OI-AUTH": "",
  "OI-CHN": 0,
  // 渠道ID
  "OI-WXAPP-SESSION": "",
  "OI-TYPE": "USER",
  "OI-APIVER": "58"
};function setToken(token) {
  HEADER["OI-AUTH"] = token;
}function setChannel(chn) {
  HEADER["OI-CHN"] = chn;
}function setUdid(udid) {
  HEADER["OI-UDID"] = md5(udid);
}function setSession(session) {
  HEADER["OI-WXAPP-SESSION"] = session;
}function fetchGet(url) {
  var data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  return fetch("GET", url, data);
}function fetchPost(url) {
  var data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  return fetch("POST", url, data);
}function fetchPut(url) {
  var data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  return fetch("PUT", url, data);
}function fetchDelete(url) {
  var data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  return fetch("DELETE", url, data);
}function fetch(method, url, data) {
  var showTip = true;
  if (data.noTip) {
    showTip = false;
    delete data.noTip;
  }
  return new Promise(function (resolve, reject) {
    wx.request({
      url: url,
      method: method,
      data: data,
      header: HEADER,
      success: function success(result) {
        if (result.statusCode == 200 || result.statusCode == 201) {
          resolve(result.data);
        } else if (result.statusCode == 435) {
          app.getUserInfo(function () {
            fetch(method, url, data);
          });
        } else if (result.statusCode == 401) {
          app.checkLoginStatus();
        } else if (result.statusCode == 433) {
          resolve(result.data);
        } else if (result.statusCode == 406) {
          resolve(result.data);
        } else if (result.statusCode == 400) {
          if (result.data.msg == "invalid uid" || result.data.msg == "error session key") {
            app.logout();
            app.checkLoginStatus();
          } else {
            wx.showModal({
              title: "提示",
              content: result.data.msg,
              showCancel: false,
              confirmColor: "#ff3939",
              success: function success(res) {}
            });
          }
        } else {
          reject(result);
          if (showTip) {
            wx.showModal({
              title: "提示",
              content: result.data.msg,
              showCancel: false,
              confirmColor: "#ff3939",
              success: function success(res) {}
            });
          }
        }
      },
      fail: function fail(result) {
        reject(result);
      }
    });
  });
}module.exports = {
  header: HEADER,
  baseUrl: HOST,
  fetchGet: fetchGet,
  fetchPost: fetchPost,
  fetchPut: fetchPut,
  fetchDelete: fetchDelete,
  setToken: setToken,
  setUdid: setUdid,
  setSession: setSession,
  setChannel: setChannel
};